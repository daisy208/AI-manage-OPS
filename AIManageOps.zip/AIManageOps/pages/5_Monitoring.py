import streamlit as st
import sqlite3
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import json
from auth import check_authentication, get_user_role
from database import log_action

# Check authentication
if not check_authentication():
    st.stop()

st.title("📊 Model Monitoring")
st.markdown("Track model performance, prediction accuracy, and data drift over time")

# Get user's deployments and models
conn = sqlite3.connect('mlops_platform.db')
cursor = conn.cursor()

cursor.execute("""
    SELECT d.id, d.endpoint_name, d.status, d.prediction_count, d.last_prediction,
           m.id, m.name, m.algorithm, m.accuracy
    FROM deployments d
    JOIN models m ON d.model_id = m.id
    WHERE m.created_by = ?
    ORDER BY d.deployed_at DESC
""", (st.session_state.username,))

deployments = cursor.fetchall()
conn.close()

if not deployments:
    st.warning("No deployments found. Deploy a model to see monitoring data.")
    if st.button("Go to Model Deployment"):
        st.switch_page("pages/4_Model_Deployment.py")
    st.stop()

# Overview metrics
st.markdown("## 📈 Overview")

col1, col2, col3, col4 = st.columns(4)

with col1:
    total_deployments = len(deployments)
    active_deployments = len([d for d in deployments if d[2] == 'active'])
    st.metric("Total Deployments", total_deployments)

with col2:
    st.metric("Active Deployments", active_deployments)

with col3:
    total_predictions = sum([d[3] for d in deployments if d[3]])
    st.metric("Total Predictions", f"{total_predictions:,}")

with col4:
    # Calculate average model performance
    accuracies = [d[8] for d in deployments if d[8] is not None]
    avg_accuracy = np.mean(accuracies) if accuracies else 0
    st.metric("Avg Performance", f"{avg_accuracy:.3f}")

# Deployment selection for detailed monitoring
st.markdown("---")
st.markdown("## 🔍 Detailed Monitoring")

deployment_options = {f"{d[1]} ({d[6]})": d[0] for d in deployments}

selected_deployment_name = st.selectbox(
    "Select deployment to monitor:",
    list(deployment_options.keys())
)

selected_deployment_id = deployment_options[selected_deployment_name]

# Get selected deployment details
selected_deployment = None
for d in deployments:
    if d[0] == selected_deployment_id:
        selected_deployment = d
        break

if selected_deployment:
    dep_id, endpoint_name, status, pred_count, last_pred, model_id, model_name, algorithm, accuracy = selected_deployment
    
    # Deployment info
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Model Name", model_name)
        st.metric("Algorithm", algorithm)
    
    with col2:
        status_color = {"active": "🟢", "inactive": "🔴"}
        st.metric("Status", f"{status_color.get(status, '⚪')} {status.title()}")
        st.metric("Endpoint", endpoint_name)
    
    with col3:
        st.metric("Predictions Made", f"{pred_count:,}" if pred_count else "0")
        if last_pred:
            st.metric("Last Prediction", last_pred.split('T')[0])

# Fetch real prediction data from database
@st.cache_data(ttl=300)  # Cache for 5 minutes to avoid frequent DB calls
def get_real_prediction_data(deployment_id, days=30):
    """Fetch real prediction data from the database."""
    try:
        conn = sqlite3.connect('mlops_platform.db')
        cursor = conn.cursor()
        
        # Get model_id for this deployment
        cursor.execute("SELECT model_id FROM deployments WHERE id = ?", (deployment_id,))
        result = cursor.fetchone()
        
        if not result:
            conn.close()
            return pd.DataFrame()
        
        model_id = result[0]
        
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        # Fetch prediction data (use SQLite datetime format)
        cursor.execute("""
            SELECT 
                p.predicted_at as timestamp,
                p.prediction,
                p.confidence,
                p.actual_value as actual,
                p.input_data
            FROM predictions p
            WHERE p.model_id = ? 
            AND p.predicted_at >= ?
            ORDER BY p.predicted_at DESC
        """, (model_id, start_date.strftime('%Y-%m-%d %H:%M:%S')))
        
        predictions = cursor.fetchall()
        conn.close()
        
        if not predictions:
            return pd.DataFrame()
        
        # Convert to DataFrame
        data = []
        for pred in predictions:
            timestamp, prediction, confidence, actual, input_data_json = pred
            
            # Parse input data to extract features
            try:
                input_data = json.loads(input_data_json) if input_data_json else {}
                input_features = list(input_data.values()) if isinstance(input_data, dict) else []
            except (json.JSONDecodeError, TypeError):
                input_features = []
            
            # Simulate response time since we don't track it yet
            # In a real implementation, you'd track this in the API server
            response_time = np.random.gamma(2, 50)  # Temporary simulation
            
            # Handle both numeric and string predictions
            if prediction is not None:
                try:
                    prediction_value = float(prediction)
                except (ValueError, TypeError):
                    # Keep string predictions as-is for classification models
                    prediction_value = str(prediction)
            else:
                prediction_value = None
            
            # Handle actual values (numeric only for now)
            actual_value = None
            if actual is not None:
                try:
                    actual_value = float(actual)
                except (ValueError, TypeError):
                    actual_value = None
            
            data.append({
                'timestamp': pd.to_datetime(timestamp),
                'prediction': prediction_value,
                'confidence': float(confidence) if confidence is not None else 0.0,
                'actual': actual_value,
                'response_time': response_time,
                'input_features': input_features
            })
        
        df = pd.DataFrame(data)
        
        # If no real data, return empty DataFrame
        if df.empty:
            return pd.DataFrame()
            
        return df
        
    except Exception as e:
        st.error(f"Error fetching prediction data: {str(e)}")
        return pd.DataFrame()

# Get monitoring data
monitoring_data = get_real_prediction_data(selected_deployment_id)

if len(monitoring_data) > 0:
    # Time range selector
    st.markdown("### 📅 Time Range")
    
    col1, col2 = st.columns(2)
    
    with col1:
        time_range = st.selectbox(
            "Select time range:",
            ["Last 24 hours", "Last 7 days", "Last 30 days", "Last 90 days"]
        )
    
    with col2:
        refresh_interval = st.selectbox(
            "Refresh interval:",
            ["Manual", "30 seconds", "1 minute", "5 minutes"]
        )
    
    # Filter data based on time range
    now = datetime.now()
    if time_range == "Last 24 hours":
        cutoff = now - timedelta(hours=24)
    elif time_range == "Last 7 days":
        cutoff = now - timedelta(days=7)
    elif time_range == "Last 30 days":
        cutoff = now - timedelta(days=30)
    else:  # Last 90 days
        cutoff = now - timedelta(days=90)
    
    filtered_data = monitoring_data[monitoring_data['timestamp'] >= cutoff].copy()
    
    # Performance monitoring
    st.markdown("### 📊 Performance Metrics")
    
    if len(filtered_data) > 0:
        # Calculate metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            avg_confidence = filtered_data['confidence'].mean()
            st.metric("Avg Confidence", f"{avg_confidence:.3f}")
        
        with col2:
            avg_response_time = filtered_data['response_time'].mean()
            st.metric("Avg Response Time", f"{avg_response_time:.1f}ms")
        
        with col3:
            prediction_volume = len(filtered_data)
            st.metric("Prediction Volume", f"{prediction_volume:,}")
        
        with col4:
            # Calculate accuracy (where we have actual values and numeric predictions)
            mask = (~filtered_data['actual'].isna()) & (filtered_data['prediction'].apply(lambda x: isinstance(x, (int, float))))
            if mask.sum() > 0:
                accuracy_data = filtered_data[mask]
                mae = np.mean(np.abs(accuracy_data['prediction'] - accuracy_data['actual']))
                st.metric("Mean Abs Error", f"{mae:.3f}")
            else:
                # For classification models, show prediction count instead
                total_predictions = len(filtered_data)
                st.metric("Total Predictions", f"{total_predictions:,}")
        
        # Performance over time
        st.markdown("### 📈 Performance Trends")
        
        # Resample data for better visualization
        filtered_data['timestamp'] = pd.to_datetime(filtered_data['timestamp'])
        filtered_data.set_index('timestamp', inplace=True)
        
        # Hourly aggregation
        if time_range == "Last 24 hours":
            freq = '1H'
        elif time_range == "Last 7 days":
            freq = '6H'
        else:
            freq = '1D'
        
        hourly_data = filtered_data.resample(freq).agg({
            'confidence': 'mean',
            'response_time': 'mean',
            'prediction': 'count'
        }).reset_index()
        
        # Confidence over time
        fig_confidence = px.line(
            hourly_data,
            x='timestamp',
            y='confidence',
            title='Model Confidence Over Time',
            labels={'confidence': 'Average Confidence', 'timestamp': 'Time'}
        )
        fig_confidence.add_hline(y=0.8, line_dash="dash", line_color="red", 
                                annotation_text="Confidence Threshold")
        st.plotly_chart(fig_confidence, use_container_width=True)
        
        # Response time and volume
        col1, col2 = st.columns(2)
        
        with col1:
            fig_response = px.line(
                hourly_data,
                x='timestamp',
                y='response_time',
                title='Response Time Over Time',
                labels={'response_time': 'Avg Response Time (ms)', 'timestamp': 'Time'}
            )
            st.plotly_chart(fig_response, use_container_width=True)
        
        with col2:
            fig_volume = px.bar(
                hourly_data,
                x='timestamp',
                y='prediction',
                title='Prediction Volume Over Time',
                labels={'prediction': 'Number of Predictions', 'timestamp': 'Time'}
            )
            st.plotly_chart(fig_volume, use_container_width=True)
        
        # Data drift detection
        st.markdown("### 🌊 Data Drift Analysis")
        
        st.info("Data drift detection helps identify when incoming data differs significantly from training data.")
        
        # Feature drift simulation
        feature_names = ['Feature_1', 'Feature_2', 'Feature_3', 'Feature_4', 'Feature_5']
        
        # Calculate feature statistics over time
        feature_data = []
        for idx, row in hourly_data.iterrows():
            timestamp = row['timestamp']
            # Simulate feature drift
            for i, feature_name in enumerate(feature_names):
                drift_score = np.random.random() * 0.3  # Simulate drift score
                feature_data.append({
                    'timestamp': timestamp,
                    'feature': feature_name,
                    'drift_score': drift_score
                })
        
        drift_df = pd.DataFrame(feature_data)
        
        # Drift heatmap
        drift_pivot = drift_df.pivot(index='timestamp', columns='feature', values='drift_score')
        
        fig_drift = px.imshow(
            drift_pivot.T,
            title='Feature Drift Heatmap',
            labels={'x': 'Time', 'y': 'Features', 'color': 'Drift Score'},
            aspect='auto',
            color_continuous_scale='RdYlBu_r'
        )
        st.plotly_chart(fig_drift, use_container_width=True)
        
        # Drift threshold alerts
        col1, col2 = st.columns(2)
        
        with col1:
            drift_threshold = st.slider("Drift Alert Threshold", 0.1, 0.5, 0.2, 0.05)
        
        with col2:
            current_max_drift = drift_df['drift_score'].max()
            if current_max_drift > drift_threshold:
                st.error(f"⚠️ Data drift detected! Max drift score: {current_max_drift:.3f}")
            else:
                st.success(f"✅ No significant drift detected. Max drift score: {current_max_drift:.3f}")
        
        # Model health dashboard
        st.markdown("### 🏥 Model Health Dashboard")
        
        # Health indicators
        col1, col2, col3 = st.columns(3)
        
        with col1:
            # Confidence health
            low_confidence_ratio = (filtered_data['confidence'] < 0.7).mean()
            if low_confidence_ratio > 0.1:
                st.error(f"❌ Confidence: {low_confidence_ratio:.1%} predictions below 0.7")
            else:
                st.success(f"✅ Confidence: Only {low_confidence_ratio:.1%} predictions below 0.7")
        
        with col2:
            # Response time health
            slow_predictions = (filtered_data['response_time'] > 1000).mean()
            if slow_predictions > 0.05:
                st.warning(f"⚠️ Performance: {slow_predictions:.1%} predictions > 1s")
            else:
                st.success(f"✅ Performance: Only {slow_predictions:.1%} predictions > 1s")
        
        with col3:
            # Volume health
            recent_volume = len(filtered_data[filtered_data.index >= filtered_data.index.max() - timedelta(hours=1)])
            if recent_volume == 0:
                st.error("❌ Volume: No recent predictions")
            elif recent_volume < 5:
                st.warning(f"⚠️ Volume: Only {recent_volume} predictions in last hour")
            else:
                st.success(f"✅ Volume: {recent_volume} predictions in last hour")
        
        # Alerts and recommendations
        st.markdown("### 🚨 Alerts & Recommendations")
        
        alerts = []
        
        # Check for performance degradation
        if avg_confidence < 0.8:
            alerts.append({
                'level': 'warning',
                'message': f"Model confidence has dropped to {avg_confidence:.3f}. Consider retraining.",
                'action': 'Retrain model with recent data'
            })
        
        # Check for drift
        if current_max_drift > drift_threshold:
            alerts.append({
                'level': 'error',
                'message': f"Data drift detected (score: {current_max_drift:.3f}). Model may be stale.",
                'action': 'Investigate input data changes and consider retraining'
            })
        
        # Check for volume anomalies
        if prediction_volume == 0:
            alerts.append({
                'level': 'error',
                'message': "No predictions in selected time range.",
                'action': 'Check if deployment is active and receiving traffic'
            })
        
        # Check response time
        if avg_response_time > 500:
            alerts.append({
                'level': 'warning',
                'message': f"Average response time is {avg_response_time:.1f}ms.",
                'action': 'Consider model optimization or infrastructure scaling'
            })
        
        if alerts:
            for alert in alerts:
                if alert['level'] == 'error':
                    st.error(f"🚨 **{alert['message']}**\n\n*Recommended action:* {alert['action']}")
                else:
                    st.warning(f"⚠️ **{alert['message']}**\n\n*Recommended action:* {alert['action']}")
        else:
            st.success("✅ All systems operating normally. No alerts detected.")

else:
    st.info("No prediction data available for the selected deployment in the selected time range.")
    st.markdown("""
    **To see monitoring data:**
    1. Make sure your deployment is active
    2. Ensure the API server is running (check the workflows panel)
    3. Send prediction requests to your API endpoint with `log_prediction: true`
    4. Wait a few minutes and refresh this page to see the monitoring dashboard
    
    **Example API request:**
    ```bash
    curl -X POST "http://localhost:8000/predict/your_endpoint_name" \\
         -H "Content-Type: application/json" \\
         -d '{
           "features": {"feature1": 1.0, "feature2": 2.0},
           "log_prediction": true,
           "include_confidence": true
         }'
    ```
    """)

# Model comparison
st.markdown("---")
st.markdown("## 🔄 Model Comparison")

if len(deployments) > 1:
    st.markdown("Compare performance across different model deployments:")
    
    # Performance comparison
    comparison_data = []
    for dep in deployments:
        dep_id, endpoint_name, status, pred_count, last_pred, model_id, model_name, algorithm, accuracy = dep
        
        comparison_data.append({
            'Model': model_name,
            'Endpoint': endpoint_name,
            'Algorithm': algorithm,
            'Training Accuracy': accuracy if accuracy else 0,
            'Predictions': pred_count if pred_count else 0,
            'Status': status
        })
    
    comparison_df = pd.DataFrame(comparison_data)
    
    # Performance chart
    fig_comparison = px.bar(
        comparison_df,
        x='Model',
        y='Training Accuracy',
        color='Algorithm',
        title='Model Performance Comparison',
        text='Training Accuracy'
    )
    fig_comparison.update_traces(texttemplate='%{text:.3f}', textposition='outside')
    st.plotly_chart(fig_comparison, use_container_width=True)
    
    # Usage comparison
    fig_usage = px.pie(
        comparison_df,
        values='Predictions',
        names='Model',
        title='Prediction Volume Distribution'
    )
    st.plotly_chart(fig_usage, use_container_width=True)

# Export monitoring data
st.markdown("---")
st.markdown("## 📤 Export Monitoring Data")

col1, col2 = st.columns(2)

with col1:
    export_format = st.selectbox(
        "Export format:",
        ["CSV", "JSON"]
    )

with col2:
    if st.button("Export Data"):
        if len(monitoring_data) > 0:
            if export_format == "CSV":
                csv_data = monitoring_data.to_csv(index=False)
                st.download_button(
                    label="Download CSV",
                    data=csv_data,
                    file_name=f"monitoring_data_{endpoint_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv"
                )
            else:
                json_data = monitoring_data.to_json(orient='records', date_format='iso')
                st.download_button(
                    label="Download JSON",
                    data=json_data,
                    file_name=f"monitoring_data_{endpoint_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                    mime="application/json"
                )
        else:
            st.error("No data to export")

# Help section
with st.expander("📚 Monitoring Help"):
    st.markdown("""
    ### Key Metrics
    
    **Performance Metrics:**
    - **Confidence**: Average prediction confidence scores
    - **Response Time**: How quickly the model responds to requests
    - **Accuracy**: Comparison between predictions and actual values (when available)
    
    **Health Indicators:**
    - **Volume**: Number of predictions over time
    - **Drift Score**: Measures how much input data has changed
    - **Error Rate**: Percentage of failed predictions
    
    ### Alert Thresholds
    - **Low Confidence**: < 80% average confidence
    - **High Drift**: Drift score > 0.2
    - **Slow Response**: > 500ms average response time
    - **Low Volume**: No predictions in recent time window
    
    ### Best Practices
    1. **Regular Monitoring**: Check dashboards daily for production models
    2. **Set Alerts**: Configure automated alerts for critical thresholds
    3. **Data Quality**: Monitor input data quality and distribution
    4. **Performance Tracking**: Keep track of accuracy over time
    5. **Retraining Schedule**: Plan regular model updates based on drift detection
    
    ### Troubleshooting
    - **High Drift**: Investigate changes in data sources or user behavior
    - **Low Confidence**: May indicate model degradation or new data patterns
    - **Slow Response**: Check infrastructure resources and model complexity
    - **No Predictions**: Verify deployment status and API connectivity
    """)
