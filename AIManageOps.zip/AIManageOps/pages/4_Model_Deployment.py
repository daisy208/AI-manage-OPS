import streamlit as st
import sqlite3
import pandas as pd
import numpy as np
import json
import os
import threading
import time
from datetime import datetime
import requests
import plotly.express as px
from auth import check_authentication, get_user_role
from database import log_action

# Check authentication
if not check_authentication():
    st.stop()

st.title("🚀 Model Deployment")
st.markdown("Deploy your trained models as REST API endpoints")

# Get user's completed models
conn = sqlite3.connect('mlops_platform.db')
cursor = conn.cursor()

cursor.execute("""
    SELECT id, name, algorithm, accuracy, model_path, target_column, feature_columns
    FROM models 
    WHERE created_by = ? AND status = 'completed'
    ORDER BY created_at DESC
""", (st.session_state.username,))

available_models = cursor.fetchall()
conn.close()

if not available_models:
    st.warning("No completed models available for deployment.")
    if st.button("Go to Model Training"):
        st.switch_page("pages/2_Model_Training.py")
    st.stop()

# Model selection
st.markdown("## Select Model for Deployment")

model_options = {f"{name} ({algorithm})": model_id for model_id, name, algorithm, accuracy, model_path, target_column, feature_columns in available_models}

selected_model_name = st.selectbox(
    "Choose a model to deploy:",
    options=list(model_options.keys()),
    index=0 if 'selected_model_id' not in st.session_state else 
          list(model_options.values()).index(st.session_state.selected_model_id) if st.session_state.selected_model_id in model_options.values() else 0
)

selected_model_id = model_options[selected_model_name]

# Get selected model details
selected_model = None
model_id = None
name = ""
algorithm = ""
accuracy = None
model_path = ""
target_column = ""
feature_list = []

for model in available_models:
    if model[0] == selected_model_id:
        selected_model = model
        break

if selected_model:
    model_id, name, algorithm, accuracy, model_path, target_column, feature_columns = selected_model
    feature_list = json.loads(feature_columns) if feature_columns else []
    
    # Display model information
    st.markdown("### Model Information")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Model Name", name)
        st.metric("Algorithm", algorithm)
    
    with col2:
        st.metric("Performance", f"{accuracy:.4f}" if accuracy else "N/A")
        st.metric("Features", len(feature_list))
    
    with col3:
        st.metric("Target", target_column)
        
        # Check if already deployed
        conn = sqlite3.connect('mlops_platform.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM deployments WHERE model_id = ? AND status = 'active'", (model_id,))
        is_deployed = cursor.fetchone()[0] > 0
        conn.close()
        
        if is_deployed:
            st.success("✅ Deployed")
        else:
            st.info("⏸️ Not Deployed")

    # Deployment configuration
    st.markdown("---")
    st.markdown("## Deployment Configuration")

    col1, col2 = st.columns(2)

    with col1:
        endpoint_name = st.text_input(
            "Endpoint Name",
            value=f"{name.lower().replace(' ', '_').replace('-', '_')}",
            help="This will be part of your API URL"
        )
        
        # Validate endpoint name
        if endpoint_name:
            if not endpoint_name.replace('_', '').isalnum():
                st.error("Endpoint name can only contain letters, numbers, and underscores")
            elif len(endpoint_name) < 3:
                st.error("Endpoint name must be at least 3 characters long")

    with col2:
        deployment_description = st.text_area(
            "Description (Optional)",
            help="Describe this deployment and its intended use"
        )

    # API Configuration
    st.markdown("### API Configuration")

    col1, col2 = st.columns(2)

    with col1:
        enable_logging = st.checkbox(
            "Enable Prediction Logging",
            value=True,
            help="Log all predictions for monitoring and analysis"
        )

    with col2:
        require_auth = st.checkbox(
            "Require Authentication",
            value=False,
            help="Require API key for endpoint access"
        )

    # Preview API endpoint
    if endpoint_name and len(endpoint_name) >= 3 and endpoint_name.replace('_', '').isalnum():
        st.markdown("### API Endpoint Preview")
        api_url = f"http://localhost:8000/predict/{endpoint_name}"
        st.code(f"POST {api_url}", language="text")
        
        # Show expected input format
        st.markdown("**Expected Input Format:**")
        sample_input = {feature: f"<{feature}_value>" for feature in feature_list}
        st.json(sample_input)
        
        # Show expected output format
        st.markdown("**Expected Output Format:**")
        sample_output = {
            "prediction": "<predicted_value>",
            "confidence": "<confidence_score>",
            "model_name": name,
            "timestamp": "<prediction_timestamp>"
        }
        st.json(sample_output)

else:
    st.error("No model selected for deployment.")

# Current deployments
st.markdown("---")
st.markdown("## Current Deployments")

# Get all deployments for this user
conn = sqlite3.connect('mlops_platform.db')
cursor = conn.cursor()

cursor.execute("""
    SELECT d.id, d.endpoint_name, d.status, d.deployed_at, d.prediction_count, 
           d.last_prediction, m.name, m.algorithm
    FROM deployments d
    JOIN models m ON d.model_id = m.id
    WHERE m.created_by = ?
    ORDER BY d.deployed_at DESC
""", (st.session_state.username,))

deployments = cursor.fetchall()
conn.close()

if deployments:
    for deployment in deployments:
        dep_id, dep_endpoint, dep_status, deployed_at, pred_count, last_pred, model_name, model_algorithm = deployment
        
        with st.expander(f"🌐 {dep_endpoint} ({model_name})", expanded=False):
            col1, col2, col3 = st.columns(3)
            
            with col1:
                status_color = {"active": "🟢", "inactive": "🔴", "updating": "🟡"}
                st.markdown(f"**Status:** {status_color.get(dep_status, '⚪')} {dep_status.title()}")
                st.write(f"**Model:** {model_name}")
                st.write(f"**Algorithm:** {model_algorithm}")
            
            with col2:
                st.write(f"**Deployed:** {deployed_at}")
                st.write(f"**Predictions:** {pred_count:,}")
                if last_pred:
                    st.write(f"**Last Used:** {last_pred}")
            
            with col3:
                if dep_status == 'active':
                    if st.button("Stop", key=f"stop_{dep_id}", type="secondary"):
                        conn = sqlite3.connect('mlops_platform.db')
                        cursor = conn.cursor()
                        cursor.execute("UPDATE deployments SET status = 'inactive' WHERE id = ?", (dep_id,))
                        conn.commit()
                        conn.close()
                        
                        log_action(st.session_state.username, "deployment_stop", "deployment", dep_id)
                        st.rerun()
                
                else:
                    if st.button("Start", key=f"start_{dep_id}", type="primary"):
                        conn = sqlite3.connect('mlops_platform.db')
                        cursor = conn.cursor()
                        cursor.execute("UPDATE deployments SET status = 'active' WHERE id = ?", (dep_id,))
                        conn.commit()
                        conn.close()
                        
                        log_action(st.session_state.username, "deployment_start", "deployment", dep_id)
                        st.rerun()
                
                if st.button("Delete", key=f"delete_{dep_id}"):
                    conn = sqlite3.connect('mlops_platform.db')
                    cursor = conn.cursor()
                    cursor.execute("DELETE FROM deployments WHERE id = ?", (dep_id,))
                    cursor.execute("DELETE FROM predictions WHERE model_id = (SELECT model_id FROM deployments WHERE id = ?)", (dep_id,))
                    conn.commit()
                    conn.close()
                    
                    log_action(st.session_state.username, "deployment_delete", "deployment", dep_id)
                    st.rerun()
            
            # API endpoint info
            if dep_status == 'active':
                st.markdown("**API Endpoint:**")
                api_url = f"http://localhost:8000/predict/{dep_endpoint}"
                st.code(api_url)
                
                # Enhanced model testing with explanations
                st.markdown("#### 🧪 Test Model with Explanations")
                
                # Get model information for testing
                conn = sqlite3.connect('mlops_platform.db')
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT m.id, m.feature_columns, m.model_path, m.target_column, m.algorithm
                    FROM models m 
                    JOIN deployments d ON m.id = d.model_id 
                    WHERE d.id = ?
                """, (dep_id,))
                model_result = cursor.fetchone()
                conn.close()
                
                if model_result:
                    model_id, feature_columns_json, model_path, target_column, algorithm = model_result
                    features = json.loads(feature_columns_json)
                    
                    with st.expander(f"🔬 Interactive Model Testing", expanded=False):
                        st.markdown("Test your model with custom inputs and get detailed explanations for the predictions.")
                        
                        # Input method selection
                        input_method = st.radio(
                            "Choose input method:",
                            ["Manual Input", "Sample Data", "Upload CSV"],
                            key=f"input_method_{dep_id}",
                            horizontal=True
                        )
                        
                        test_data = {}
                        
                        if input_method == "Manual Input":
                            st.markdown("**Enter feature values:**")
                            cols = st.columns(min(3, len(features)))
                            
                            # Load model to get feature type information
                            try:
                                from utils.model_utils import load_model_package
                                model_package = load_model_package(model_path)
                                label_encoders = model_package.get('label_encoders', {})
                            except:
                                label_encoders = {}
                            
                            for i, feature in enumerate(features):
                                with cols[i % len(cols)]:
                                    # Check if feature is categorical (has label encoder)
                                    if feature in label_encoders:
                                        # Categorical feature - use selectbox
                                        try:
                                            categories = label_encoders[feature].classes_.tolist()
                                            test_data[feature] = st.selectbox(
                                                feature,
                                                options=categories,
                                                key=f"input_{dep_id}_{feature}",
                                                help=f"Select value for categorical feature {feature}"
                                            )
                                        except:
                                            # Fallback to text input if classes not available
                                            test_data[feature] = st.text_input(
                                                feature,
                                                value="",
                                                key=f"input_{dep_id}_{feature}",
                                                help=f"Enter text value for {feature}"
                                            )
                                    else:
                                        # Numeric feature - use number input
                                        test_data[feature] = st.number_input(
                                            feature,
                                            value=0.0,
                                            key=f"input_{dep_id}_{feature}",
                                            help=f"Enter numeric value for {feature}"
                                        )
                        
                        elif input_method == "Sample Data":
                            st.markdown("**Using sample test data:**")
                            
                            # Load model to get feature type information
                            try:
                                from utils.model_utils import load_model_package
                                model_package = load_model_package(model_path)
                                label_encoders = model_package.get('label_encoders', {})
                            except:
                                label_encoders = {}
                            
                            # Generate realistic sample data based on feature types
                            for feature in features:
                                if feature in label_encoders:
                                    # Categorical feature - pick random category
                                    try:
                                        categories = label_encoders[feature].classes_.tolist()
                                        test_data[feature] = np.random.choice(categories)
                                    except:
                                        test_data[feature] = "sample_value"
                                else:
                                    # Numeric feature - use reasonable range
                                    test_data[feature] = np.random.normal(0.5, 0.2)  # More realistic than uniform
                            
                            # Show the sample data in editable format
                            edited_data = {}
                            cols = st.columns(min(3, len(features)))
                            for i, (feature, value) in enumerate(test_data.items()):
                                with cols[i % len(cols)]:
                                    if feature in label_encoders:
                                        # Categorical feature - use selectbox
                                        try:
                                            categories = label_encoders[feature].classes_.tolist()
                                            current_index = categories.index(value) if value in categories else 0
                                            edited_data[feature] = st.selectbox(
                                                feature,
                                                options=categories,
                                                index=current_index,
                                                key=f"sample_{dep_id}_{feature}",
                                                help=f"Sample value for categorical feature {feature}"
                                            )
                                        except:
                                            edited_data[feature] = st.text_input(
                                                feature,
                                                value=str(value),
                                                key=f"sample_{dep_id}_{feature}",
                                                help=f"Sample value for {feature}"
                                            )
                                    else:
                                        # Numeric feature - use number input
                                        edited_data[feature] = st.number_input(
                                            feature,
                                            value=float(value),
                                            key=f"sample_{dep_id}_{feature}",
                                            help=f"Sample value for {feature}"
                                        )
                            test_data = edited_data
                        
                        elif input_method == "Upload CSV":
                            uploaded_file = st.file_uploader(
                                "Upload CSV with test data",
                                type=['csv'],
                                key=f"upload_{dep_id}",
                                help="Upload a CSV file with feature columns matching your model"
                            )
                            
                            if uploaded_file is not None:
                                try:
                                    test_df = pd.read_csv(uploaded_file)
                                    
                                    if len(test_df) > 0:
                                        row_index = st.selectbox(
                                            "Select row to test:",
                                            range(len(test_df)),
                                            format_func=lambda x: f"Row {x + 1}",
                                            key=f"row_select_{dep_id}"
                                        )
                                        
                                        test_row = test_df.iloc[row_index]
                                        test_data = {feature: test_row.get(feature, 0) for feature in features}
                                        
                                        st.markdown("**Selected test data:**")
                                        st.json(test_data)
                                    else:
                                        st.error("CSV file is empty")
                                        test_data = {}
                                except Exception as e:
                                    st.error(f"Error reading CSV: {str(e)}")
                                    test_data = {}
                        
                        # Explanation options
                        st.markdown("**Explanation Options:**")
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            include_lime = st.checkbox(
                                "LIME Explanation",
                                value=True,
                                key=f"lime_{dep_id}",
                                help="Generate LIME explanation for this prediction"
                            )
                            
                            include_feature_importance = st.checkbox(
                                "Feature Importance",
                                value=True,
                                key=f"feat_imp_{dep_id}",
                                help="Show global feature importance from the model"
                            )
                        
                        with col2:
                            if include_lime:
                                num_features = st.slider(
                                    "Number of features to explain",
                                    min_value=3,
                                    max_value=min(len(features), 15),
                                    value=min(8, len(features)),
                                    key=f"num_feat_{dep_id}",
                                    help="How many top features to include in LIME explanation"
                                )
                        
                        # Test button
                        if st.button(f"🚀 Test Model & Explain", key=f"test_explain_{dep_id}", type="primary"):
                            if test_data:
                                # Validate that we have all required features
                                missing_features = [f for f in features if f not in test_data]
                                if missing_features:
                                    st.error(f"Missing values for features: {', '.join(missing_features)}")
                                elif any(v == "" or v is None for v in test_data.values()):
                                    # Check for empty categorical values
                                    empty_values = [f for f, v in test_data.items() if v == "" or v is None]
                                    st.error(f"Please provide values for: {', '.join(empty_values)}")
                                else:
                                    try:
                                        with st.spinner("Making prediction and generating explanations..."):
                                            # Load model and make prediction with explanations
                                            from utils.model_utils import load_model_package, get_prediction_explanation
                                            
                                            model_package = load_model_package(model_path)
                                            
                                            # Test preprocessing first to give clear error messages
                                            try:
                                                from utils.model_utils import preprocess_input_data
                                                test_X = preprocess_input_data(test_data, model_package)
                                                st.success("✅ Data preprocessing successful")
                                                
                                                # Determine explanation type
                                                explanation_type = 'both' if include_lime and include_feature_importance else \
                                                               'lime' if include_lime else 'feature_importance'
                                                
                                                explanations = get_prediction_explanation(
                                                    model_package,
                                                    test_data,
                                                    explanation_type=explanation_type,
                                                    num_features=num_features if include_lime else 10
                                                )
                                                
                                                if 'error' in explanations:
                                                    st.error(f"❌ Explanation generation failed: {explanations['error']}")
                                                    st.info("**Troubleshooting:**\n"
                                                           "- Try using fewer features for LIME explanation\n"
                                                           "- Check if input values are within reasonable ranges\n"
                                                           "- Consider using only Feature Importance if LIME fails")
                                                else:
                                            # Display results
                                            st.markdown("### 🎯 Prediction Results")
                                            
                                            # Main prediction result
                                            result_col1, result_col2 = st.columns(2)
                                            with result_col1:
                                                prediction = explanations['prediction_result']['prediction']
                                                confidence = explanations['prediction_result']['confidence']
                                                
                                                st.metric(
                                                    "Prediction",
                                                    f"{prediction}" if isinstance(prediction, str) else f"{prediction:.4f}",
                                                    help="Model prediction for the input data"
                                                )
                                            
                                            with result_col2:
                                                st.metric(
                                                    "Confidence",
                                                    f"{confidence:.3f}",
                                                    help="Model confidence in this prediction"
                                                )
                                            
                                            # Feature Importance Explanation
                                            if include_feature_importance and 'feature_importance' in explanations['explanations']:
                                                st.markdown("### 📊 Global Feature Importance")
                                                st.markdown("*How important each feature is across all predictions*")
                                                
                                                feat_imp = explanations['explanations']['feature_importance']
                                                if feat_imp and 'error' not in feat_imp[0]:
                                                    # Create feature importance chart
                                                    feat_df = pd.DataFrame(feat_imp[:10])  # Top 10 features
                                                    
                                                    if not feat_df.empty:
                                                        fig_importance = px.bar(
                                                            feat_df,
                                                            x='importance',
                                                            y='feature',
                                                            orientation='h',
                                                            title='Top 10 Most Important Features',
                                                            labels={'importance': 'Importance Score', 'feature': 'Features'}
                                                        )
                                                        fig_importance.update_layout(height=400, yaxis={'categoryorder': 'total ascending'})
                                                        st.plotly_chart(fig_importance, use_container_width=True)
                                                else:
                                                    st.info("Feature importance not available for this model type")
                                            
                                            # LIME Explanation
                                            if include_lime and 'lime' in explanations['explanations']:
                                                lime_data = explanations['explanations']['lime']
                                                
                                                if 'error' not in lime_data:
                                                    st.markdown("### 🔍 LIME Explanation")
                                                    st.markdown("*How each feature influenced this specific prediction*")
                                                    
                                                    # LIME explanation chart
                                                    lime_features = lime_data['feature_explanations']
                                                    if lime_features:
                                                        lime_df = pd.DataFrame(lime_features)
                                                        
                                                        # Create LIME chart
                                                        colors = ['green' if w > 0 else 'red' for w in lime_df['weight']]
                                                        
                                                        fig_lime = px.bar(
                                                            lime_df,
                                                            x='weight',
                                                            y='feature',
                                                            orientation='h',
                                                            title=f'LIME Explanation - Feature Contributions',
                                                            labels={'weight': 'Contribution to Prediction', 'feature': 'Features'},
                                                            color='weight',
                                                            color_continuous_scale=['red', 'white', 'green']
                                                        )
                                                        fig_lime.update_layout(
                                                            height=400,
                                                            yaxis={'categoryorder': 'total ascending'},
                                                            coloraxis_showscale=False
                                                        )
                                                        st.plotly_chart(fig_lime, use_container_width=True)
                                                        
                                                        # LIME explanation table
                                                        st.markdown("**Detailed Feature Contributions:**")
                                                        display_df = lime_df[['feature', 'weight', 'contribution']].copy()
                                                        display_df['weight'] = display_df['weight'].round(4)
                                                        display_df.columns = ['Feature', 'Contribution Weight', 'Effect']
                                                        st.dataframe(display_df, use_container_width=True)
                                                else:
                                                    st.error(f"LIME explanation error: {lime_data['error']}")
                                            
                                            # Input Analysis
                                            if 'input_analysis' in explanations:
                                                st.markdown("### 🔬 Input Feature Analysis")
                                                
                                                analysis_data = []
                                                for feat_info in explanations['input_analysis']:
                                                    analysis_data.append({
                                                        'Feature': feat_info['feature'],
                                                        'Input Value': feat_info['value'],
                                                        'Global Rank': feat_info.get('importance_rank', 'N/A'),
                                                        'LIME Weight': f"{feat_info.get('lime_weight', 0):.4f}" if feat_info.get('lime_weight') is not None else 'N/A',
                                                        'LIME Effect': feat_info.get('lime_contribution', 'N/A')
                                                    })
                                                
                                                analysis_df = pd.DataFrame(analysis_data)
                                                st.dataframe(analysis_df, use_container_width=True)
                                
                                except Exception as e:
                                    st.error(f"Error during prediction/explanation: {str(e)}")
                            else:
                                st.error("Please provide valid numeric values for all features")

else:
    st.info("No deployments found. Deploy your first model below!")

# Deployment action
st.markdown("---")
st.markdown("## Deploy New Model")

if st.button("🚀 Deploy Model", type="primary", use_container_width=True):
    if not endpoint_name:
        st.error("Please provide an endpoint name")
    elif len(endpoint_name) < 3:
        st.error("Endpoint name must be at least 3 characters long")
    elif not endpoint_name.replace('_', '').isalnum():
        st.error("Endpoint name can only contain letters, numbers, and underscores")
    else:
        # Check if endpoint name already exists
        conn = sqlite3.connect('mlops_platform.db')
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM deployments WHERE endpoint_name = ? AND status = 'active'", (endpoint_name,))
        if cursor.fetchone()[0] > 0:
            st.error("Endpoint name already in use. Please choose a different name.")
            conn.close()
        else:
            try:
                # Create deployment record
                api_endpoint = f"http://localhost:8000/predict/{endpoint_name}"
                
                cursor.execute("""
                    INSERT INTO deployments (model_id, endpoint_name, status, deployed_by, api_endpoint)
                    VALUES (?, ?, ?, ?, ?)
                """, (model_id, endpoint_name, 'active', st.session_state.username, api_endpoint))
                
                deployment_id = cursor.lastrowid
                conn.commit()
                conn.close()
                
                # Log action
                log_action(
                    st.session_state.username,
                    "model_deployment",
                    "deployment",
                    deployment_id,
                    f"Deployed model {name} as {endpoint_name}"
                )
                
                st.success(f"Model '{name}' deployed successfully!")
                st.info(f"API endpoint: {api_endpoint}")
                
                # Show next steps
                st.markdown("### Next Steps")
                st.markdown("""
                1. **Start the API Server**: Run the API server to handle requests
                2. **Test Your Endpoint**: Use the test functionality above
                3. **Monitor Performance**: Check the monitoring dashboard
                4. **Share with Team**: Provide the API endpoint to your team
                """)
                
                st.rerun()
                
            except Exception as e:
                st.error(f"Error deploying model: {str(e)}")

# API Server Management
st.markdown("---")
st.markdown("## API Server Management")

st.markdown("""
### Starting the API Server

To serve your deployed models, you need to start the API server separately:

```bash
python api_server.py
```

The API server will start on port 8000 and provide REST endpoints for all your deployed models.

### Usage Examples

Once the API server is running, you can make predictions using HTTP requests:

```python
import requests

# Example prediction request
response = requests.post(
    "http://localhost:8000/predict/your_endpoint_name",
    json={
        "features": {
            "feature1": 1.0,
            "feature2": 2.0
            # ... other features
        },
        "include_confidence": True,
        "log_prediction": True
    }
)

prediction = response.json()
print(prediction)
```

### API Documentation

- **GET /**: API information and status
- **GET /health**: General health check
- **GET /deployments**: List all active deployments
- **POST /predict/{endpoint_name}**: Make single predictions
- **POST /predict/{endpoint_name}/batch**: Make batch predictions
- **GET /predict/{endpoint_name}/health**: Check model health
- **GET /predict/{endpoint_name}/schema**: Get model input schema
""")
