import streamlit as st
import sqlite3
import pandas as pd
import json
import os
import joblib
from datetime import datetime
import plotly.express as px
import plotly.graph_objects as go
from auth import check_authentication, get_user_role
from database import log_action, get_user_models

# Check authentication
if not check_authentication():
    st.stop()

st.title("📋 Model Registry")
st.markdown("Manage and track your trained machine learning models")

# Get user's models
models = get_user_models(st.session_state.username)

if not models:
    st.info("No models found. Train your first model to get started!")
    if st.button("Go to Model Training"):
        st.switch_page("pages/2_Model_Training.py")
    st.stop()

# Model statistics
st.markdown("## 📊 Model Overview")

col1, col2, col3, col4 = st.columns(4)

with col1:
    total_models = len(models)
    st.metric("Total Models", total_models)

with col2:
    completed_models = len([m for m in models if m[4] == 'completed'])
    st.metric("Completed", completed_models)

with col3:
    training_models = len([m for m in models if m[4] == 'training'])
    st.metric("Training", training_models)

with col4:
    # Get deployment count
    conn = sqlite3.connect('mlops_platform.db')
    cursor = conn.cursor()
    cursor.execute("""
        SELECT COUNT(*) FROM deployments d
        JOIN models m ON d.model_id = m.id
        WHERE m.created_by = ? AND d.status = 'active'
    """, (st.session_state.username,))
    deployed_count = cursor.fetchone()[0]
    conn.close()
    
    st.metric("Deployed", deployed_count)

# Model performance chart
if completed_models > 0:
    st.markdown("## 📈 Model Performance Comparison")
    
    completed_model_data = [m for m in models if m[4] == 'completed' and m[3] is not None]
    
    if completed_model_data:
        # Create performance chart
        model_names = [m[1] for m in completed_model_data]
        algorithms = [m[2] for m in completed_model_data]
        accuracies = [m[3] for m in completed_model_data]
        
        fig = px.bar(
            x=model_names,
            y=accuracies,
            color=algorithms,
            title="Model Performance Comparison",
            labels={'x': 'Model Name', 'y': 'Primary Metric', 'color': 'Algorithm'},
            text=[f"{acc:.3f}" for acc in accuracies]
        )
        
        fig.update_traces(textposition='outside')
        fig.update_layout(xaxis_tickangle=-45)
        
        st.plotly_chart(fig, use_container_width=True)

# Model list and management
st.markdown("## 🗂️ Your Models")

# Filter and sort options
col1, col2, col3 = st.columns(3)

with col1:
    status_filter = st.selectbox(
        "Filter by Status",
        ["All", "completed", "training", "failed"]
    )

with col2:
    algorithm_filter = st.selectbox(
        "Filter by Algorithm",
        ["All"] + list(set([m[2] for m in models]))
    )

with col3:
    sort_by = st.selectbox(
        "Sort by",
        ["Created Date (Newest)", "Created Date (Oldest)", "Performance (Best)", "Name (A-Z)"]
    )

# Apply filters
filtered_models = models.copy()

if status_filter != "All":
    filtered_models = [m for m in filtered_models if m[4] == status_filter]

if algorithm_filter != "All":
    filtered_models = [m for m in filtered_models if m[2] == algorithm_filter]

# Apply sorting
if sort_by == "Created Date (Newest)":
    filtered_models.sort(key=lambda x: x[5], reverse=True)
elif sort_by == "Created Date (Oldest)":
    filtered_models.sort(key=lambda x: x[5])
elif sort_by == "Performance (Best)":
    filtered_models.sort(key=lambda x: x[3] if x[3] is not None else 0, reverse=True)
elif sort_by == "Name (A-Z)":
    filtered_models.sort(key=lambda x: x[1])

# Display models
for model in filtered_models:
    model_id, name, algorithm, accuracy, status, created_at, version, tags = model
    
    # Get additional model details
    conn = sqlite3.connect('mlops_platform.db')
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT target_column, feature_columns, precision_score, recall_score, f1_score, 
               description, model_path
        FROM models WHERE id = ?
    """, (model_id,))
    
    details = cursor.fetchone()
    
    # Check if deployed
    cursor.execute("SELECT COUNT(*) FROM deployments WHERE model_id = ? AND status = 'active'", (model_id,))
    is_deployed = cursor.fetchone()[0] > 0
    
    conn.close()
    
    if details:
        target_column, feature_columns, precision_score, recall_score, f1_score, description, model_path = details
        feature_list = json.loads(feature_columns) if feature_columns else []
        
        # Model card
        with st.expander(f"🤖 {name} ({algorithm})", expanded=False):
            # Header with status and actions
            col1, col2, col3, col4 = st.columns([2, 1, 1, 1])
            
            with col1:
                status_color = {"completed": "🟢", "training": "🟡", "failed": "🔴"}
                st.markdown(f"**Status:** {status_color.get(status, '⚪')} {status.title()}")
                
                if is_deployed:
                    st.markdown("**🚀 Deployed**")
            
            with col2:
                if status == 'completed':
                    if st.button("Deploy", key=f"deploy_{model_id}"):
                        st.session_state.selected_model_id = model_id
                        st.switch_page("pages/4_Model_Deployment.py")
            
            with col3:
                if st.button("Download", key=f"download_{model_id}"):
                    if os.path.exists(model_path):
                        with open(model_path, "rb") as file:
                            st.download_button(
                                label="Download Model",
                                data=file.read(),
                                file_name=f"{name}.joblib",
                                mime="application/octet-stream",
                                key=f"download_btn_{model_id}"
                            )
                    else:
                        st.error("Model file not found")
            
            with col4:
                if st.button("Delete", key=f"delete_{model_id}", type="secondary"):
                    st.session_state.delete_model_id = model_id
            
            # Model details
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**Model Information:**")
                st.write(f"**Target Column:** {target_column}")
                st.write(f"**Features:** {len(feature_list)} columns")
                st.write(f"**Version:** {version}")
                st.write(f"**Created:** {created_at}")
                
                if description:
                    st.write(f"**Description:** {description}")
                
                if tags:
                    st.write(f"**Tags:** {tags}")
            
            with col2:
                if status == 'completed' and accuracy is not None:
                    st.markdown("**Performance Metrics:**")
                    
                    # Primary metric
                    primary_metric_name = "Accuracy" if precision_score else "R² Score"
                    st.metric(primary_metric_name, f"{accuracy:.4f}")
                    
                    # Additional metrics
                    if precision_score is not None:
                        col_a, col_b = st.columns(2)
                        with col_a:
                            st.metric("Precision", f"{precision_score:.4f}")
                            st.metric("Recall", f"{recall_score:.4f}")
                        with col_b:
                            st.metric("F1 Score", f"{f1_score:.4f}")
            
            # Feature list
            if feature_list:
                st.markdown("**Features Used:**")
                
                # Display features in a nice grid
                feature_cols = st.columns(min(len(feature_list), 4))
                for i, feature in enumerate(feature_list):
                    with feature_cols[i % len(feature_cols)]:
                        st.write(f"• {feature}")
            
            # Model insights (if model file exists and is loaded)
            if status == 'completed' and os.path.exists(model_path):
                if st.checkbox("Show Model Insights", key=f"insights_{model_id}"):
                    try:
                        model_package = joblib.load(model_path)
                        model = model_package['model']
                        
                        # Feature importance for tree-based models
                        if hasattr(model, 'feature_importances_'):
                            st.markdown("**Feature Importance:**")
                            
                            importance_df = pd.DataFrame({
                                'Feature': feature_list,
                                'Importance': model.feature_importances_
                            }).sort_values('Importance', ascending=False)
                            
                            fig = px.bar(
                                importance_df.head(10),
                                x='Importance',
                                y='Feature',
                                orientation='h',
                                title="Top 10 Most Important Features"
                            )
                            fig.update_layout(height=400)
                            st.plotly_chart(fig, use_container_width=True)
                        
                        # Model parameters
                        if hasattr(model, 'get_params'):
                            st.markdown("**Model Parameters:**")
                            params = model.get_params()
                            param_df = pd.DataFrame([
                                {'Parameter': k, 'Value': str(v)} 
                                for k, v in params.items()
                            ])
                            st.dataframe(param_df, use_container_width=True)
                    
                    except Exception as e:
                        st.error(f"Error loading model insights: {str(e)}")

# Handle model deletion
if 'delete_model_id' in st.session_state:
    model_to_delete = st.session_state.delete_model_id
    
    st.warning("⚠️ Confirm Model Deletion")
    
    col1, col2, col3 = st.columns([1, 1, 2])
    
    with col1:
        if st.button("✅ Confirm Delete", type="primary"):
            try:
                conn = sqlite3.connect('mlops_platform.db')
                cursor = conn.cursor()
                
                # Get model details for cleanup
                cursor.execute("SELECT name, model_path FROM models WHERE id = ?", (model_to_delete,))
                model_details = cursor.fetchone()
                
                if model_details:
                    model_name, model_path = model_details
                    
                    # Delete model file
                    if os.path.exists(model_path):
                        os.remove(model_path)
                    
                    # Delete from database
                    cursor.execute("DELETE FROM models WHERE id = ?", (model_to_delete,))
                    cursor.execute("DELETE FROM deployments WHERE model_id = ?", (model_to_delete,))
                    cursor.execute("DELETE FROM predictions WHERE model_id = ?", (model_to_delete,))
                    
                    conn.commit()
                    
                    # Log action
                    log_action(
                        st.session_state.username,
                        "model_deletion",
                        "model",
                        model_to_delete,
                        f"Deleted model: {model_name}"
                    )
                    
                    st.success(f"Model '{model_name}' deleted successfully!")
                    
                else:
                    st.error("Model not found")
                
                conn.close()
                del st.session_state.delete_model_id
                st.rerun()
                
            except Exception as e:
                st.error(f"Error deleting model: {str(e)}")
    
    with col2:
        if st.button("❌ Cancel"):
            del st.session_state.delete_model_id
            st.rerun()

# Model versioning section
st.markdown("---")
st.markdown("## 🔄 Model Versioning")

# Group models by name (ignoring version)
model_families = {}
for model in models:
    base_name = model[1].rsplit('_v', 1)[0] if '_v' in model[1] else model[1]
    if base_name not in model_families:
        model_families[base_name] = []
    model_families[base_name].append(model)

if len(model_families) > 1:
    selected_family = st.selectbox(
        "Select Model Family",
        list(model_families.keys())
    )
    
    family_models = model_families[selected_family]
    family_models.sort(key=lambda x: x[6], reverse=True)  # Sort by version
    
    if len(family_models) > 1:
        # Version comparison
        st.markdown(f"**Versions of {selected_family}:**")
        
        version_data = []
        for model in family_models:
            version_data.append({
                'Version': model[6],
                'Algorithm': model[2],
                'Performance': model[3] if model[3] else 0,
                'Status': model[4],
                'Created': model[5]
            })
        
        version_df = pd.DataFrame(version_data)
        st.dataframe(version_df, use_container_width=True)
        
        # Performance trend
        if len([m for m in family_models if m[3] is not None]) > 1:
            perf_data = [(m[6], m[3]) for m in family_models if m[3] is not None]
            perf_data.sort(key=lambda x: x[0])
            
            fig = px.line(
                x=[p[0] for p in perf_data],
                y=[p[1] for p in perf_data],
                title=f"Performance Trend for {selected_family}",
                labels={'x': 'Version', 'y': 'Performance Metric'},
                markers=True
            )
            
            st.plotly_chart(fig, use_container_width=True)

# Export models
st.markdown("---")
st.markdown("## 📤 Export Models")

export_format = st.selectbox(
    "Export Format",
    ["Model Registry Report (CSV)", "Model Metadata (JSON)"]
)

if st.button("Generate Export"):
    if export_format == "Model Registry Report (CSV)":
        # Create CSV report
        export_data = []
        for model in models:
            model_id, name, algorithm, accuracy, status, created_at, version, tags = model
            export_data.append({
                'Model Name': name,
                'Algorithm': algorithm,
                'Performance': accuracy if accuracy else 'N/A',
                'Status': status,
                'Version': version,
                'Created Date': created_at,
                'Tags': tags if tags else ''
            })
        
        export_df = pd.DataFrame(export_data)
        csv = export_df.to_csv(index=False)
        
        st.download_button(
            label="Download CSV Report",
            data=csv,
            file_name=f"model_registry_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )
    
    else:
        # Create JSON metadata
        metadata = {
            'export_date': datetime.now().isoformat(),
            'total_models': len(models),
            'user': st.session_state.username,
            'models': []
        }
        
        for model in models:
            model_id, name, algorithm, accuracy, status, created_at, version, tags = model
            
            # Get additional details
            conn = sqlite3.connect('mlops_platform.db')
            cursor = conn.cursor()
            cursor.execute("""
                SELECT target_column, feature_columns, hyperparameters, description
                FROM models WHERE id = ?
            """, (model_id,))
            details = cursor.fetchone()
            conn.close()
            
            model_metadata = {
                'id': model_id,
                'name': name,
                'algorithm': algorithm,
                'performance': accuracy,
                'status': status,
                'version': version,
                'created_date': created_at,
                'tags': tags
            }
            
            if details:
                target_column, feature_columns, hyperparameters, description = details
                model_metadata.update({
                    'target_column': target_column,
                    'feature_columns': json.loads(feature_columns) if feature_columns else [],
                    'hyperparameters': json.loads(hyperparameters) if hyperparameters else {},
                    'description': description
                })
            
            metadata['models'].append(model_metadata)
        
        json_str = json.dumps(metadata, indent=2)
        
        st.download_button(
            label="Download JSON Metadata",
            data=json_str,
            file_name=f"model_metadata_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            mime="application/json"
        )

# Help section
with st.expander("📚 Registry Help"):
    st.markdown("""
    ### Model Management
    - **Deploy**: Create an API endpoint for your model
    - **Download**: Get the model file for external use
    - **Delete**: Remove model and all associated data
    - **Insights**: View feature importance and model parameters
    
    ### Model Versioning
    - Models with similar names are grouped into families
    - Version numbers help track model evolution
    - Compare performance across versions
    
    ### Performance Metrics
    - **Classification**: Accuracy, Precision, Recall, F1 Score
    - **Regression**: R² Score, MSE, RMSE
    - Higher values generally indicate better performance
    
    ### Best Practices
    - Use descriptive model names
    - Add tags for easy filtering
    - Include descriptions for context
    - Regularly clean up old/unused models
    """)
