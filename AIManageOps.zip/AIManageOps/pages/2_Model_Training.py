import streamlit as st
import pandas as pd
import numpy as np
import sqlite3
import json
import joblib
import os
from datetime import datetime
from sklearn.model_selection import train_test_split, GridSearchCV, RandomizedSearchCV, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, mean_squared_error, r2_score
from sklearn.feature_selection import SelectKBest, f_classif, f_regression
import xgboost as xgb
import plotly.express as px
import plotly.graph_objects as go
from auth import check_authentication, get_user_role
from database import log_action, get_user_datasets

# Check authentication
if not check_authentication():
    st.stop()

st.title("🔬 Model Training")
st.markdown("Train machine learning models with automated hyperparameter optimization")

# Dataset selection
st.markdown("## Select Dataset")

datasets = get_user_datasets(st.session_state.username)

if not datasets:
    st.warning("No datasets found. Please upload a dataset first.")
    if st.button("Go to Data Upload"):
        st.switch_page("pages/1_Data_Upload.py")
    st.stop()

# Create dataset options
dataset_options = {f"{name} ({row_count:,} rows)": dataset_id for dataset_id, name, filename, file_size, uploaded_at, row_count in datasets}

selected_dataset_name = st.selectbox(
    "Choose a dataset for training:",
    options=list(dataset_options.keys()),
    index=0 if 'selected_dataset_id' not in st.session_state else 
          list(dataset_options.values()).index(st.session_state.selected_dataset_id) if st.session_state.selected_dataset_id in dataset_options.values() else 0
)

selected_dataset_id = dataset_options[selected_dataset_name]

# Load dataset
@st.cache_data
def load_dataset(dataset_id):
    conn = sqlite3.connect('mlops_platform.db')
    cursor = conn.cursor()
    
    cursor.execute("SELECT file_path, columns_info FROM datasets WHERE id = ?", (dataset_id,))
    result = cursor.fetchone()
    conn.close()
    
    if result:
        file_path, columns_info = result
        if file_path.endswith('.csv'):
            df = pd.read_csv(file_path)
        else:
            df = pd.read_json(file_path)
        
        return df, json.loads(columns_info) if columns_info else []
    return None, []

df, column_info = load_dataset(selected_dataset_id)

if df is not None:
    # Dataset preview
    with st.expander("📊 Dataset Preview", expanded=False):
        st.dataframe(df.head(), use_container_width=True)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Rows", len(df))
        with col2:
            st.metric("Columns", len(df.columns))
        with col3:
            st.metric("Missing Values", df.isnull().sum().sum())
    
    # Model configuration
    st.markdown("## Model Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Problem type
        problem_type = st.selectbox(
            "Problem Type",
            ["Classification", "Regression"],
            help="Choose the type of machine learning problem"
        )
        
        # Target column
        target_column = st.selectbox(
            "Target Column",
            df.columns.tolist(),
            help="Select the column you want to predict"
        )
    
    with col2:
        # Algorithm selection
        if problem_type == "Classification":
            algorithm_options = {
                "Logistic Regression": "logistic_regression",
                "Random Forest": "random_forest_classifier",
                "XGBoost": "xgboost_classifier"
            }
        else:
            algorithm_options = {
                "Linear Regression": "linear_regression",
                "Random Forest": "random_forest_regressor",
                "XGBoost": "xgboost_regressor"
            }
        
        selected_algorithm = st.selectbox(
            "Algorithm",
            list(algorithm_options.keys()),
            help="Choose the machine learning algorithm"
        )
        
        algorithm_key = algorithm_options[selected_algorithm]
    
    # Training mode selection
    st.markdown("### Training Mode")
    
    training_mode = st.radio(
        "Choose training approach:",
        ["Manual Training", "AutoML (Automated)"],
        index=0,
        help="Manual: Configure hyperparameters yourself. AutoML: Automatically optimize hyperparameters."
    )
    
    # Feature selection
    st.markdown("### Feature Selection")
    
    available_features = [col for col in df.columns if col != target_column]
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        select_all = st.checkbox("Select All Features", value=True)
    
    with col2:
        if select_all:
            selected_features = available_features
        else:
            selected_features = st.multiselect(
                "Select Features",
                available_features,
                default=available_features[:5] if len(available_features) > 5 else available_features
            )
    
    if not selected_features:
        st.error("Please select at least one feature for training.")
        st.stop()
    
    # Data preprocessing options
    st.markdown("### Preprocessing Options")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        handle_missing = st.selectbox(
            "Handle Missing Values",
            ["Drop rows", "Fill with mean", "Fill with median", "Fill with mode"],
            help="How to handle missing values in the data"
        )
    
    with col2:
        scale_features = st.checkbox(
            "Scale Features",
            value=True if algorithm_key in ["logistic_regression", "linear_regression"] else False,
            help="Standardize features (recommended for linear models)"
        )
    
    with col3:
        test_size = st.slider(
            "Test Size",
            min_value=0.1,
            max_value=0.5,
            value=0.2,
            step=0.05,
            help="Proportion of data to use for testing"
        )
    
    # Hyperparameter tuning
    st.markdown("### Hyperparameters")
    
    hyperparams = {}
    automl_config = {}
    
    if training_mode == "Manual Training":
        # Manual hyperparameter configuration (existing code)
        if algorithm_key == "random_forest_classifier" or algorithm_key == "random_forest_regressor":
            col1, col2, col3 = st.columns(3)
            with col1:
                hyperparams['n_estimators'] = st.slider("Number of Trees", 10, 200, 100)
            with col2:
                hyperparams['max_depth'] = st.slider("Max Depth", 3, 20, 10)
            with col3:
                hyperparams['min_samples_split'] = st.slider("Min Samples Split", 2, 20, 2)
        
        elif "xgboost" in algorithm_key:
            col1, col2, col3 = st.columns(3)
            with col1:
                hyperparams['n_estimators'] = st.slider("Number of Estimators", 50, 500, 100)
            with col2:
                hyperparams['max_depth'] = st.slider("Max Depth", 3, 10, 6)
            with col3:
                hyperparams['learning_rate'] = st.slider("Learning Rate", 0.01, 0.3, 0.1)
                
    else:  # AutoML mode
        st.info("🤖 AutoML will automatically find the best hyperparameters for your model.")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Search strategy
            automl_config['search_strategy'] = st.selectbox(
                "Search Strategy",
                ["Random Search", "Grid Search"],
                index=0,
                help="Random Search is faster, Grid Search is more thorough"
            )
            
            # Number of iterations/trials
            if automl_config['search_strategy'] == "Random Search":
                automl_config['n_iter'] = st.slider(
                    "Number of Random Trials",
                    min_value=10,
                    max_value=100,
                    value=50,
                    help="More trials = better results but longer training time"
                )
            else:
                st.info("Grid Search will test all parameter combinations")
        
        with col2:
            # Cross-validation folds
            automl_config['cv_folds'] = st.slider(
                "Cross-Validation Folds",
                min_value=3,
                max_value=10,
                value=5,
                help="Number of folds for cross-validation"
            )
            
            # Multi-algorithm comparison
            automl_config['compare_algorithms'] = st.checkbox(
                "Compare Multiple Algorithms",
                value=True,
                help="Test all available algorithms and pick the best one"
            )
        
        # AutoML feature selection
        automl_config['auto_feature_selection'] = st.checkbox(
            "Automatic Feature Selection",
            value=False,
            help="Automatically select the most important features"
        )
        
        if automl_config['auto_feature_selection']:
            max_available_features = len(selected_features)
            automl_config['max_features'] = st.slider(
                "Maximum Features to Select",
                min_value=min(1, max_available_features),
                max_value=min(max_available_features, 50),
                value=min(15, max_available_features),
                help="Maximum number of features to keep after selection"
            )
    
    # AutoML helper functions
    def get_hyperparameter_grid(algorithm_key, search_strategy="Random Search"):
        """Get hyperparameter grid for AutoML search."""
        if algorithm_key == "random_forest_classifier" or algorithm_key == "random_forest_regressor":
            if search_strategy == "Grid Search":
                return {
                    'n_estimators': [50, 100, 200],
                    'max_depth': [5, 10, 15, 20],
                    'min_samples_split': [2, 5, 10],
                    'min_samples_leaf': [1, 2, 4]
                }
            else:  # Random Search
                return {
                    'n_estimators': list(range(50, 201, 10)),
                    'max_depth': list(range(3, 21)),
                    'min_samples_split': list(range(2, 21)),
                    'min_samples_leaf': list(range(1, 11))
                }
        
        elif "xgboost" in algorithm_key:
            if search_strategy == "Grid Search":
                return {
                    'n_estimators': [50, 100, 200],
                    'max_depth': [3, 6, 9],
                    'learning_rate': [0.01, 0.1, 0.2],
                    'subsample': [0.8, 0.9, 1.0]
                }
            else:  # Random Search
                return {
                    'n_estimators': list(range(50, 501, 25)),
                    'max_depth': list(range(3, 11)),
                    'learning_rate': [0.01, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3],
                    'subsample': [0.6, 0.7, 0.8, 0.9, 1.0],
                    'colsample_bytree': [0.6, 0.7, 0.8, 0.9, 1.0]
                }
        
        elif algorithm_key == "logistic_regression":
            if search_strategy == "Grid Search":
                # Use only valid solver-penalty combinations
                return [
                    {'C': [0.001, 0.01, 0.1, 1, 10, 100], 'penalty': ['l2'], 'solver': ['lbfgs']},
                    {'C': [0.001, 0.01, 0.1, 1, 10, 100], 'penalty': ['l1', 'l2'], 'solver': ['liblinear']}
                ]
            else:  # Random Search - use separate valid combinations
                return [
                    {'C': [0.001, 0.01, 0.1, 1, 10, 100], 'penalty': ['l2'], 'solver': ['lbfgs']},
                    {'C': [0.001, 0.01, 0.1, 1, 10, 100], 'penalty': ['l1'], 'solver': ['liblinear']},
                    {'C': [0.001, 0.01, 0.1, 1, 10, 100], 'penalty': ['l2'], 'solver': ['liblinear']}
                ]
        
        return {}  # No hyperparameters for linear regression
    
    def run_automl_search(X_train, y_train, algorithm_key, problem_type, automl_config):
        """Run automated hyperparameter search."""
        param_grid = get_hyperparameter_grid(algorithm_key, automl_config['search_strategy'])
        
        if not param_grid:
            # No hyperparameters to tune
            if algorithm_key == "linear_regression":
                return LinearRegression(), {}
            elif algorithm_key == "logistic_regression":
                return LogisticRegression(random_state=42, max_iter=1000), {}
        
        # Initialize base model
        if algorithm_key == "random_forest_classifier":
            base_model = RandomForestClassifier(random_state=42)
        elif algorithm_key == "random_forest_regressor":
            base_model = RandomForestRegressor(random_state=42)
        elif algorithm_key == "xgboost_classifier":
            base_model = xgb.XGBClassifier(random_state=42, eval_metric='logloss')
        elif algorithm_key == "xgboost_regressor":
            base_model = xgb.XGBRegressor(random_state=42)
        elif algorithm_key == "logistic_regression":
            base_model = LogisticRegression(random_state=42, max_iter=1000)
        
        # Choose scoring metric
        if problem_type == "Classification":
            scoring = 'accuracy'
        else:
            scoring = 'r2'
        
        # Run search (handle both dict and list param grids)
        if automl_config['search_strategy'] == "Grid Search":
            search = GridSearchCV(
                base_model, 
                param_grid, 
                cv=automl_config['cv_folds'], 
                scoring=scoring,
                n_jobs=-1,
                verbose=1
            )
        else:  # Random Search
            # For RandomizedSearchCV with list of dicts, we need to handle it differently
            if isinstance(param_grid, list):
                # For logistic regression with multiple parameter combinations
                all_results = []
                for param_subset in param_grid:
                    search = RandomizedSearchCV(
                        base_model, 
                        param_subset, 
                        cv=automl_config['cv_folds'], 
                        scoring=scoring,
                        n_iter=min(automl_config['n_iter'] // len(param_grid), 10),  # Distribute iterations
                        n_jobs=-1,
                        random_state=42,
                        verbose=1
                    )
                    search.fit(X_train, y_train)
                    all_results.append((search.best_score_, search.best_estimator_, search.best_params_))
                
                # Find the best result across all parameter subsets
                best_score, best_model, best_params = max(all_results, key=lambda x: x[0])
                return best_model, best_params
            else:
                search = RandomizedSearchCV(
                    base_model, 
                    param_grid, 
                    cv=automl_config['cv_folds'], 
                    scoring=scoring,
                    n_iter=automl_config['n_iter'],
                    n_jobs=-1,
                    random_state=42,
                    verbose=1
                )
        
        search.fit(X_train, y_train)
        return search.best_estimator_, search.best_params_
    
    def compare_algorithms(X_train, y_train, problem_type, automl_config):
        """Compare multiple algorithms and return the best one."""
        if problem_type == "Classification":
            algorithms = {
                "Logistic Regression": "logistic_regression",
                "Random Forest": "random_forest_classifier",
                "XGBoost": "xgboost_classifier"
            }
        else:
            algorithms = {
                "Linear Regression": "linear_regression",
                "Random Forest": "random_forest_regressor",
                "XGBoost": "xgboost_regressor"
            }
        
        results = []
        
        for algo_name, algo_key in algorithms.items():
            try:
                model, best_params = run_automl_search(X_train, y_train, algo_key, problem_type, automl_config)
                
                # Evaluate with cross-validation
                if problem_type == "Classification":
                    scores = cross_val_score(model, X_train, y_train, cv=automl_config['cv_folds'], scoring='accuracy')
                else:
                    scores = cross_val_score(model, X_train, y_train, cv=automl_config['cv_folds'], scoring='r2')
                
                results.append({
                    'algorithm': algo_name,
                    'algorithm_key': algo_key,
                    'model': model,
                    'best_params': best_params,
                    'cv_score_mean': scores.mean(),
                    'cv_score_std': scores.std()
                })
                
            except Exception as e:
                st.warning(f"Failed to train {algo_name}: {str(e)}")
                continue
        
        if not results:
            raise Exception("All algorithms failed to train")
        
        # Sort by performance
        results.sort(key=lambda x: x['cv_score_mean'], reverse=True)
        return results
    
    # Model training
    st.markdown("---")
    st.markdown("## Train Model")
    
    model_name = st.text_input(
        "Model Name",
        value=f"{selected_algorithm}_{datetime.now().strftime('%Y%m%d_%H%M')}",
        help="Enter a name for this model"
    )
    
    model_description = st.text_area(
        "Model Description (Optional)",
        help="Describe this model and its purpose"
    )
    
    if st.button("🚀 Start Training", type="primary", use_container_width=True):
        if not model_name:
            st.error("Please provide a model name")
            st.stop()
        
        try:
            with st.spinner("Training model... This may take a few minutes."):
                # Prepare data
                X = df[selected_features].copy()
                y = df[target_column].copy()
                
                # Handle missing values
                if handle_missing == "Drop rows":
                    mask = ~(X.isnull().any(axis=1) | y.isnull())
                    X = X[mask]
                    y = y[mask]
                elif handle_missing == "Fill with mean":
                    X = X.fillna(X.mean())
                    if y.dtype in ['int64', 'float64']:
                        y = y.fillna(y.mean())
                elif handle_missing == "Fill with median":
                    X = X.fillna(X.median())
                    if y.dtype in ['int64', 'float64']:
                        y = y.fillna(y.median())
                elif handle_missing == "Fill with mode":
                    for col in X.columns:
                        X[col] = X[col].fillna(X[col].mode()[0] if len(X[col].mode()) > 0 else 0)
                    if len(y.mode()) > 0:
                        y = y.fillna(y.mode()[0])
                
                # Encode categorical variables
                categorical_cols = X.select_dtypes(include=['object']).columns
                label_encoders = {}
                
                for col in categorical_cols:
                    le = LabelEncoder()
                    X[col] = le.fit_transform(X[col].astype(str))
                    label_encoders[col] = le
                
                # Encode target if classification
                target_encoder = None
                if problem_type == "Classification" and y.dtype == 'object':
                    target_encoder = LabelEncoder()
                    y = target_encoder.fit_transform(y.astype(str))
                
                # Split data
                X_train, X_test, y_train, y_test = train_test_split(
                    X, y, test_size=test_size, random_state=42
                )
                
                # Automatic feature selection (if requested)
                if training_mode == "AutoML (Automated)" and automl_config.get('auto_feature_selection', False):
                    if problem_type == "Classification":
                        selector = SelectKBest(score_func=f_classif, k=automl_config['max_features'])
                    else:
                        selector = SelectKBest(score_func=f_regression, k=automl_config['max_features'])
                    
                    X_train_selected = selector.fit_transform(X_train, y_train)
                    X_test_selected = selector.transform(X_test)
                    
                    # Update feature names
                    selected_feature_indices = selector.get_support(indices=True)
                    selected_features_auto = [selected_features[i] for i in selected_feature_indices]
                    
                    X_train = pd.DataFrame(X_train_selected, columns=selected_features_auto)
                    X_test = pd.DataFrame(X_test_selected, columns=selected_features_auto)
                    selected_features = selected_features_auto
                    
                    st.info(f"✨ AutoML selected {len(selected_features)} most important features: {', '.join(selected_features[:5])}{'...' if len(selected_features) > 5 else ''}")
                
                # Scale features if requested
                scaler = None
                if scale_features:
                    scaler = StandardScaler()
                    X_train = scaler.fit_transform(X_train)
                    X_test = scaler.transform(X_test)
                
                # Training logic based on mode
                best_params = {}
                automl_results = []
                
                if training_mode == "Manual Training":
                    # Manual training with user-specified hyperparameters
                    if algorithm_key == "linear_regression":
                        model = LinearRegression()
                    elif algorithm_key == "logistic_regression":
                        model = LogisticRegression(random_state=42, max_iter=1000)
                    elif algorithm_key == "random_forest_classifier":
                        model = RandomForestClassifier(random_state=42, **hyperparams)
                    elif algorithm_key == "random_forest_regressor":
                        model = RandomForestRegressor(random_state=42, **hyperparams)
                    elif algorithm_key == "xgboost_classifier":
                        model = xgb.XGBClassifier(random_state=42, **hyperparams)
                    elif algorithm_key == "xgboost_regressor":
                        model = xgb.XGBRegressor(random_state=42, **hyperparams)
                    
                    # Train model
                    model.fit(X_train, y_train)
                    algorithm_display_name = selected_algorithm
                    
                else:  # AutoML mode
                    st.info("🤖 Running AutoML optimization...")
                    
                    if automl_config.get('compare_algorithms', False):
                        # Compare multiple algorithms
                        progress_bar = st.progress(0)
                        status_text = st.empty()
                        
                        status_text.text("Comparing algorithms and optimizing hyperparameters...")
                        automl_results = compare_algorithms(X_train, y_train, problem_type, automl_config)
                        progress_bar.progress(100)
                        
                        # Use the best algorithm
                        best_result = automl_results[0]
                        model = best_result['model']
                        best_params = best_result['best_params']
                        algorithm_display_name = best_result['algorithm']
                        algorithm_key = best_result['algorithm_key']
                        
                        # Show comparison results
                        st.success(f"🏆 Best algorithm: {algorithm_display_name} (CV Score: {best_result['cv_score_mean']:.4f} ± {best_result['cv_score_std']:.4f})")
                        
                        # Show algorithm comparison table
                        comparison_df = pd.DataFrame([{
                            'Algorithm': r['algorithm'],
                            'CV Score': f"{r['cv_score_mean']:.4f} ± {r['cv_score_std']:.4f}",
                            'Best Parameters': str(r['best_params'])[:100] + '...' if len(str(r['best_params'])) > 100 else str(r['best_params'])
                        } for r in automl_results])
                        
                        st.markdown("### 📊 Algorithm Comparison Results")
                        st.dataframe(comparison_df, use_container_width=True)
                        
                    else:
                        # Optimize single algorithm
                        progress_bar = st.progress(0)
                        status_text = st.empty()
                        
                        status_text.text(f"Optimizing {selected_algorithm} hyperparameters...")
                        model, best_params = run_automl_search(X_train, y_train, algorithm_key, problem_type, automl_config)
                        progress_bar.progress(100)
                        
                        algorithm_display_name = selected_algorithm
                        
                        st.success(f"✅ Hyperparameter optimization completed!")
                    
                    # Show best parameters
                    if best_params:
                        st.markdown("### 🎯 Best Hyperparameters Found")
                        param_cols = st.columns(min(3, len(best_params)))
                        for i, (param, value) in enumerate(best_params.items()):
                            with param_cols[i % len(param_cols)]:
                                st.metric(param, str(value))
                
                # Final model training on full training set (for AutoML, the model is already trained)
                if training_mode == "Manual Training":
                    pass  # Model already trained above
                else:
                    # For AutoML, retrain the best model on the full training set if needed
                    # (GridSearchCV/RandomizedSearchCV already does this with refit=True by default)
                    pass
                
                # Make predictions
                y_pred = model.predict(X_test)
                
                # Calculate metrics
                if problem_type == "Classification":
                    accuracy = accuracy_score(y_test, y_pred)
                    precision = precision_score(y_test, y_pred, average='weighted', zero_division=0)
                    recall = recall_score(y_test, y_pred, average='weighted', zero_division=0)
                    f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)
                    
                    primary_metric = accuracy
                    metrics = {
                        'accuracy': accuracy,
                        'precision': precision,
                        'recall': recall,
                        'f1_score': f1
                    }
                else:
                    mse = mean_squared_error(y_test, y_pred)
                    r2 = r2_score(y_test, y_pred)
                    rmse = np.sqrt(mse)
                    
                    primary_metric = r2
                    metrics = {
                        'r2_score': r2,
                        'mse': mse,
                        'rmse': rmse
                    }
                
                # Prepare hyperparameters for saving
                if training_mode == "AutoML (Automated)":
                    # For AutoML, save the optimized parameters and include AutoML metadata
                    hyperparams_to_save = best_params.copy()
                    hyperparams_to_save['_automl_mode'] = True
                    hyperparams_to_save['_search_strategy'] = automl_config.get('search_strategy', 'Random Search')
                    hyperparams_to_save['_cv_folds'] = automl_config.get('cv_folds', 5)
                    if automl_config.get('compare_algorithms', False):
                        hyperparams_to_save['_algorithm_comparison'] = [r['algorithm'] for r in automl_results[:3]]
                        hyperparams_to_save['_cv_scores'] = [f"{r['cv_score_mean']:.4f}" for r in automl_results[:3]]
                    
                    # Update model name for AutoML
                    if 'AutoML' not in model_name:
                        model_name = f"AutoML_{model_name}"
                else:
                    hyperparams_to_save = hyperparams
                
                # Save model
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                model_filename = f"{timestamp}_{model_name.replace(' ', '_')}.joblib"
                model_path = os.path.join("models/trained_models", model_filename)
                
                # Create model package with AutoML metadata
                model_package = {
                    'model': model,
                    'scaler': scaler,
                    'label_encoders': label_encoders,
                    'target_encoder': target_encoder,
                    'feature_columns': selected_features,
                    'target_column': target_column,
                    'problem_type': problem_type,
                    'training_mode': training_mode,
                    'automl_config': automl_config if training_mode == "AutoML (Automated)" else None,
                    'best_params': best_params if training_mode == "AutoML (Automated)" else None
                }
                
                joblib.dump(model_package, model_path)
                
                # Save to database
                conn = sqlite3.connect('mlops_platform.db')
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO models (name, algorithm, dataset_id, target_column, feature_columns,
                                      hyperparameters, accuracy, precision_score, recall_score, f1_score,
                                      model_path, status, created_by, description)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    model_name,
                    algorithm_display_name,  # Use the actual algorithm name (might be different for AutoML)
                    selected_dataset_id,
                    target_column,
                    json.dumps(selected_features),
                    json.dumps(hyperparams_to_save),
                    primary_metric,
                    metrics.get('precision', None),
                    metrics.get('recall', None),
                    metrics.get('f1_score', None),
                    model_path,
                    'completed',
                    st.session_state.username,
                    model_description
                ))
                
                model_id = cursor.lastrowid
                conn.commit()
                conn.close()
                
                # Log action
                log_action(
                    st.session_state.username,
                    "model_training",
                    "model",
                    model_id,
                    f"Trained model: {model_name} with {selected_algorithm}"
                )
                
                st.success(f"Model '{model_name}' trained successfully!")
                
                # Display results
                st.markdown("### Training Results")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("**Model Metrics:**")
                    for metric, value in metrics.items():
                        st.metric(metric.replace('_', ' ').title(), f"{value:.4f}")
                
                with col2:
                    # Feature importance (if available)
                    if hasattr(model, 'feature_importances_'):
                        st.markdown("**Feature Importance:**")
                        importance_df = pd.DataFrame({
                            'Feature': selected_features,
                            'Importance': model.feature_importances_
                        }).sort_values('Importance', ascending=False)
                        
                        fig = px.bar(
                            importance_df.head(10),
                            x='Importance',
                            y='Feature',
                            orientation='h',
                            title="Top 10 Feature Importance"
                        )
                        st.plotly_chart(fig, use_container_width=True)
                
                # Prediction vs Actual plot
                if problem_type == "Regression":
                    st.markdown("### Prediction vs Actual")
                    
                    fig = px.scatter(
                        x=y_test,
                        y=y_pred,
                        title="Prediction vs Actual Values",
                        labels={'x': 'Actual Values', 'y': 'Predicted Values'}
                    )
                    
                    # Add diagonal line
                    min_val = min(min(y_test), min(y_pred))
                    max_val = max(max(y_test), max(y_pred))
                    fig.add_shape(
                        type="line",
                        x0=min_val, y0=min_val,
                        x1=max_val, y1=max_val,
                        line=dict(dash="dash", color="red")
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                
                else:
                    # Confusion matrix for classification
                    from sklearn.metrics import confusion_matrix
                    
                    cm = confusion_matrix(y_test, y_pred)
                    
                    fig = px.imshow(
                        cm,
                        text_auto=True,
                        aspect="auto",
                        title="Confusion Matrix",
                        color_continuous_scale="Blues"
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                
                st.info("Your model has been saved and is ready for deployment!")
                
                if st.button("Go to Model Registry"):
                    st.switch_page("pages/3_Model_Registry.py")
        
        except Exception as e:
            st.error(f"Error during training: {str(e)}")
            st.exception(e)

else:
    st.error("Could not load the selected dataset.")

# Help section
with st.expander("📚 Training Guidelines"):
    st.markdown("""
    ### Algorithm Selection Guide
    
    **Classification Problems:**
    - **Logistic Regression**: Good for linear relationships, interpretable
    - **Random Forest**: Handles non-linear relationships, robust to outliers
    - **XGBoost**: Often highest performance, good for competitions
    
    **Regression Problems:**
    - **Linear Regression**: Simple, interpretable, good baseline
    - **Random Forest**: Handles non-linear relationships well
    - **XGBoost**: Often highest performance for complex patterns
    
    ### Data Preprocessing Tips
    - **Missing Values**: Choose appropriate strategy based on your data
    - **Feature Scaling**: Important for linear models, less important for tree-based models
    - **Test Size**: 20% is typical, use smaller for small datasets
    
    ### Hyperparameter Guidelines
    - Start with default values and adjust based on performance
    - More trees/estimators usually improve performance but increase training time
    - Lower learning rates often work better but require more estimators
    - Adjust max_depth to control overfitting
    """)
