import streamlit as st
import pandas as pd
import numpy as np
import sqlite3
import os
from datetime import datetime
import json
from auth import check_authentication, get_user_role
from database import log_action

# Check authentication
if not check_authentication():
    st.stop()

st.title("📁 Data Upload")
st.markdown("Upload and preview your datasets for model training")

# File upload section
st.markdown("## Upload Dataset")

uploaded_file = st.file_uploader(
    "Choose a CSV or JSON file",
    type=['csv', 'json'],
    help="Upload your dataset in CSV or JSON format"
)

if uploaded_file is not None:
    try:
        # Read the file based on its type
        if uploaded_file.name.endswith('.csv'):
            df = pd.read_csv(uploaded_file)
        elif uploaded_file.name.endswith('.json'):
            df = pd.read_json(uploaded_file)
        
        # Display basic information
        st.success(f"File '{uploaded_file.name}' uploaded successfully!")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Rows", len(df))
        with col2:
            st.metric("Columns", len(df.columns))
        with col3:
            st.metric("File Size", f"{uploaded_file.size / 1024:.1f} KB")
        
        # Data preview
        st.markdown("### Data Preview")
        st.dataframe(df.head(10), use_container_width=True)
        
        # Data information
        st.markdown("### Column Information")
        
        # Create column info
        column_info = []
        for col in df.columns:
            dtype = str(df[col].dtype)
            null_count = df[col].isnull().sum()
            unique_count = df[col].nunique()
            
            column_info.append({
                'Column': col,
                'Data Type': dtype,
                'Null Values': null_count,
                'Unique Values': unique_count,
                'Sample Values': ', '.join(map(str, df[col].dropna().unique()[:3]))
            })
        
        info_df = pd.DataFrame(column_info)
        st.dataframe(info_df, use_container_width=True)
        
        # Data quality checks
        st.markdown("### Data Quality Summary")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Missing Values by Column:**")
            missing_data = df.isnull().sum()
            missing_data = missing_data[missing_data > 0]
            
            if len(missing_data) > 0:
                st.dataframe(missing_data.to_frame('Missing Count'), use_container_width=True)
            else:
                st.success("No missing values found!")
        
        with col2:
            st.markdown("**Data Types Distribution:**")
            dtype_counts = df.dtypes.value_counts()
            st.dataframe(dtype_counts.to_frame('Count'), use_container_width=True)
        
        # Statistical summary for numeric columns
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            st.markdown("### Statistical Summary (Numeric Columns)")
            st.dataframe(df[numeric_cols].describe(), use_container_width=True)
        
        # Data visualization
        if len(numeric_cols) > 0:
            st.markdown("### Data Distribution")
            
            selected_column = st.selectbox(
                "Select a numeric column to visualize:",
                numeric_cols
            )
            
            if selected_column:
                import plotly.express as px
                
                col1, col2 = st.columns(2)
                
                with col1:
                    # Histogram
                    fig_hist = px.histogram(
                        df, 
                        x=selected_column, 
                        title=f"Distribution of {selected_column}",
                        nbins=30
                    )
                    st.plotly_chart(fig_hist, use_container_width=True)
                
                with col2:
                    # Box plot
                    fig_box = px.box(
                        df, 
                        y=selected_column, 
                        title=f"Box Plot of {selected_column}"
                    )
                    st.plotly_chart(fig_box, use_container_width=True)
        
        # Save dataset form
        st.markdown("### Save Dataset")
        
        with st.form("save_dataset"):
            dataset_name = st.text_input(
                "Dataset Name",
                value=uploaded_file.name.split('.')[0],
                help="Enter a name for this dataset"
            )
            
            dataset_description = st.text_area(
                "Description (Optional)",
                help="Describe what this dataset contains and its purpose"
            )
            
            save_button = st.form_submit_button("Save Dataset", type="primary")
            
            if save_button:
                if dataset_name:
                    try:
                        # Save file to disk
                        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                        filename = f"{timestamp}_{uploaded_file.name}"
                        file_path = os.path.join("data/uploads", filename)
                        
                        # Save the dataframe
                        if uploaded_file.name.endswith('.csv'):
                            df.to_csv(file_path, index=False)
                        else:
                            df.to_json(file_path, orient='records')
                        
                        # Save metadata to database
                        conn = sqlite3.connect('mlops_platform.db')
                        cursor = conn.cursor()
                        
                        column_info_json = json.dumps(column_info)
                        
                        cursor.execute('''
                            INSERT INTO datasets (name, filename, file_path, file_size, uploaded_by, 
                                                description, columns_info, row_count)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        ''', (
                            dataset_name,
                            uploaded_file.name,
                            file_path,
                            uploaded_file.size,
                            st.session_state.username,
                            dataset_description,
                            column_info_json,
                            len(df)
                        ))
                        
                        dataset_id = cursor.lastrowid
                        conn.commit()
                        conn.close()
                        
                        # Log the action
                        log_action(
                            st.session_state.username,
                            "dataset_upload",
                            "dataset",
                            dataset_id,
                            f"Uploaded dataset: {dataset_name}"
                        )
                        
                        st.success(f"Dataset '{dataset_name}' saved successfully!")
                        st.info("You can now use this dataset for model training.")
                        
                    except Exception as e:
                        st.error(f"Error saving dataset: {str(e)}")
                else:
                    st.error("Please provide a dataset name")

    except Exception as e:
        st.error(f"Error reading file: {str(e)}")
        st.info("Please make sure your file is a valid CSV or JSON format.")

# Existing datasets section
st.markdown("---")
st.markdown("## Your Uploaded Datasets")

# Get user's datasets
conn = sqlite3.connect('mlops_platform.db')
cursor = conn.cursor()

cursor.execute('''
    SELECT id, name, filename, file_size, uploaded_at, row_count, description
    FROM datasets 
    WHERE uploaded_by = ?
    ORDER BY uploaded_at DESC
''', (st.session_state.username,))

datasets = cursor.fetchall()
conn.close()

if datasets:
    # Display datasets in a nice format
    for dataset in datasets:
        dataset_id, name, filename, file_size, uploaded_at, row_count, description = dataset
        
        with st.expander(f"📊 {name}"):
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.write(f"**Original File:** {filename}")
                st.write(f"**Uploaded:** {uploaded_at}")
            
            with col2:
                st.write(f"**Rows:** {row_count:,}")
                st.write(f"**Size:** {file_size / 1024:.1f} KB")
            
            with col3:
                if st.button(f"Use for Training", key=f"train_{dataset_id}"):
                    st.session_state.selected_dataset_id = dataset_id
                    st.switch_page("pages/2_Model_Training.py")
            
            if description:
                st.write(f"**Description:** {description}")
else:
    st.info("No datasets uploaded yet. Upload your first dataset above!")

# Help section
with st.expander("📚 Help & Guidelines"):
    st.markdown("""
    ### Supported File Formats
    - **CSV**: Comma-separated values with headers
    - **JSON**: JavaScript Object Notation (array of objects or records format)
    
    ### Data Quality Tips
    - Ensure your data has clear column headers
    - Check for missing values and consider how to handle them
    - Numeric columns should contain only numbers (no text mixed in)
    - For classification tasks, ensure target column has clear categories
    - For regression tasks, ensure target column is numeric
    
    ### Best Practices
    - Keep file sizes reasonable (under 100MB for best performance)
    - Use descriptive column names
    - Include a target column if you plan to do supervised learning
    - Remove any personally identifiable information (PII) before upload
    """)
