import streamlit as st
import sqlite3
import pandas as pd
from datetime import datetime, timedelta
from auth import check_authentication, get_user_role, get_all_users, update_user_role, register_user
from database import log_action

# Check authentication
if not check_authentication():
    st.stop()

# Check if user has admin privileges
user_role = get_user_role(st.session_state.username)

st.title("👥 Team Management")
st.markdown("Manage team members, roles, and collaboration settings")

# Role-based access control
if user_role not in ['Admin', 'Data Scientist']:
    st.error("⛔ Access Denied: You need Admin or Data Scientist privileges to access team management.")
    st.info("Contact your administrator to request elevated permissions.")
    st.stop()

# Team overview
st.markdown("## 👨‍👩‍👧‍👦 Team Overview")

# Get all users
users = get_all_users()

col1, col2, col3, col4 = st.columns(4)

with col1:
    total_users = len(users)
    st.metric("Total Users", total_users)

with col2:
    admin_count = len([u for u in users if u[1] == 'Admin'])
    st.metric("Admins", admin_count)

with col3:
    data_scientist_count = len([u for u in users if u[1] == 'Data Scientist'])
    st.metric("Data Scientists", data_scientist_count)

with col4:
    viewer_count = len([u for u in users if u[1] == 'Viewer'])
    st.metric("Viewers", viewer_count)

# User management
st.markdown("---")
st.markdown("## 👤 User Management")

# Add new user (Admin only)
if user_role == 'Admin':
    st.markdown("### ➕ Add New User")
    
    with st.expander("Add New Team Member", expanded=False):
        with st.form("add_user_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                new_username = st.text_input("Username", help="Choose a unique username")
                new_password = st.text_input("Temporary Password", type="password", help="User can change this later")
            
            with col2:
                new_role = st.selectbox("Role", ["Viewer", "Data Scientist", "Admin"])
                send_invite = st.checkbox("Send invitation email", help="Email invitation with login details")
            
            user_description = st.text_area("Description (Optional)", help="Add notes about this user")
            
            add_user_button = st.form_submit_button("Add User", type="primary")
            
            if add_user_button:
                if new_username and new_password:
                    if len(new_password) >= 6:
                        success, message = register_user(new_username, new_password, new_role)
                        if success:
                            st.success(f"User '{new_username}' added successfully with role '{new_role}'!")
                            
                            # Log the action
                            log_action(
                                st.session_state.username,
                                "user_creation",
                                "user",
                                None,
                                f"Created user: {new_username} with role: {new_role}"
                            )
                            
                            if send_invite:
                                st.info("📧 Invitation email would be sent (email service not configured)")
                            
                            st.rerun()
                        else:
                            st.error(message)
                    else:
                        st.error("Password must be at least 6 characters long")
                else:
                    st.error("Please provide both username and password")

# Current team members
st.markdown("### 👥 Current Team Members")

if users:
    # Create user DataFrame
    user_data = []
    for username, role, created_at, last_login in users:
        # Get user statistics
        conn = sqlite3.connect('mlops_platform.db')
        cursor = conn.cursor()
        
        # Count models
        cursor.execute("SELECT COUNT(*) FROM models WHERE created_by = ?", (username,))
        model_count = cursor.fetchone()[0]
        
        # Count datasets
        cursor.execute("SELECT COUNT(*) FROM datasets WHERE uploaded_by = ?", (username,))
        dataset_count = cursor.fetchone()[0]
        
        # Count deployments
        cursor.execute("""
            SELECT COUNT(*) FROM deployments d
            JOIN models m ON d.model_id = m.id
            WHERE m.created_by = ?
        """, (username,))
        deployment_count = cursor.fetchone()[0]
        
        conn.close()
        
        user_data.append({
            'Username': username,
            'Role': role,
            'Models': model_count,
            'Datasets': dataset_count,
            'Deployments': deployment_count,
            'Created': created_at.split('T')[0] if created_at else 'N/A',
            'Last Login': last_login.split('T')[0] if last_login else 'Never'
        })
    
    users_df = pd.DataFrame(user_data)
    
    # Display users with management options
    for _, user in users_df.iterrows():
        with st.expander(f"👤 {user['Username']} ({user['Role']})", expanded=False):
            col1, col2, col3 = st.columns([2, 1, 1])
            
            with col1:
                st.write(f"**Role:** {user['Role']}")
                st.write(f"**Models Created:** {user['Models']}")
                st.write(f"**Datasets Uploaded:** {user['Datasets']}")
                st.write(f"**Active Deployments:** {user['Deployments']}")
                st.write(f"**Member Since:** {user['Created']}")
                st.write(f"**Last Login:** {user['Last Login']}")
            
            with col2:
                # Role change (Admin only)
                if user_role == 'Admin' and user['Username'] != st.session_state.username:
                    new_role = st.selectbox(
                        "Change Role",
                        ["Viewer", "Data Scientist", "Admin"],
                        index=["Viewer", "Data Scientist", "Admin"].index(user['Role']),
                        key=f"role_{user['Username']}"
                    )
                    
                    if st.button("Update Role", key=f"update_{user['Username']}"):
                        if new_role != user['Role']:
                            update_user_role(user['Username'], new_role)
                            log_action(
                                st.session_state.username,
                                "role_change",
                                "user",
                                None,
                                f"Changed role of {user['Username']} from {user['Role']} to {new_role}"
                            )
                            st.success(f"Role updated to {new_role}")
                            st.rerun()
            
            with col3:
                # User actions
                if user['Username'] != st.session_state.username:
                    if st.button("Reset Password", key=f"reset_{user['Username']}", help="Generate new temporary password"):
                        # In a real system, this would generate and send a new password
                        st.info("Password reset email would be sent (not implemented)")
                    
                    if user_role == 'Admin':
                        if st.button("Deactivate", key=f"deactivate_{user['Username']}", type="secondary"):
                            st.warning("User deactivation not implemented in this demo")

else:
    st.info("No users found in the system")

# Role permissions
st.markdown("---")
st.markdown("## 🔐 Role Permissions")

permissions_data = {
    'Permission': [
        'View Dashboard',
        'Upload Data',
        'Train Models',
        'View All Models',
        'Deploy Models',
        'Monitor Deployments',
        'Manage Team',
        'System Settings',
        'Delete Models',
        'Manage Users'
    ],
    'Viewer': ['✅', '❌', '❌', '❌', '❌', '❌', '❌', '❌', '❌', '❌'],
    'Data Scientist': ['✅', '✅', '✅', '✅', '✅', '✅', '✅', '❌', '✅', '❌'],
    'Admin': ['✅', '✅', '✅', '✅', '✅', '✅', '✅', '✅', '✅', '✅']
}

permissions_df = pd.DataFrame(permissions_data)
st.dataframe(permissions_df, use_container_width=True)

# Activity monitoring
st.markdown("---")
st.markdown("## 📊 Team Activity")

# Get recent activity
conn = sqlite3.connect('mlops_platform.db')
cursor = conn.cursor()

cursor.execute("""
    SELECT user_id, action, resource_type, details, timestamp
    FROM audit_logs
    ORDER BY timestamp DESC
    LIMIT 20
""", )

recent_activity = cursor.fetchall()
conn.close()

if recent_activity:
    st.markdown("### Recent Team Activity")
    
    activity_data = []
    for user_id, action, resource_type, details, timestamp in recent_activity:
        activity_data.append({
            'User': user_id,
            'Action': action.replace('_', ' ').title(),
            'Resource': resource_type.title() if resource_type else 'System',
            'Details': details or 'N/A',
            'Time': timestamp.split('T')[0] if 'T' in timestamp else timestamp
        })
    
    activity_df = pd.DataFrame(activity_data)
    st.dataframe(activity_df, use_container_width=True)
    
    # Activity summary charts
    col1, col2 = st.columns(2)
    
    with col1:
        # Activity by user
        user_activity = activity_df['User'].value_counts()
        import plotly.express as px
        
        fig_users = px.bar(
            x=user_activity.index,
            y=user_activity.values,
            title="Activity by User",
            labels={'x': 'User', 'y': 'Actions'}
        )
        st.plotly_chart(fig_users, use_container_width=True)
    
    with col2:
        # Activity by type
        action_activity = activity_df['Action'].value_counts()
        
        fig_actions = px.pie(
            values=action_activity.values,
            names=action_activity.index,
            title="Activity by Type"
        )
        st.plotly_chart(fig_actions, use_container_width=True)

else:
    st.info("No recent activity to display")

# Team collaboration settings
st.markdown("---")
st.markdown("## 🤝 Collaboration Settings")

col1, col2 = st.columns(2)

with col1:
    st.markdown("### Model Sharing")
    
    default_model_sharing = st.selectbox(
        "Default model visibility:",
        ["Private (creator only)", "Team (all members)", "Public (read-only)"],
        help="Set default sharing level for new models"
    )
    
    allow_model_collaboration = st.checkbox(
        "Allow collaborative model editing",
        value=True,
        help="Let team members edit models created by others"
    )
    
    require_approval = st.checkbox(
        "Require approval for deployments",
        value=False,
        help="Admin approval required before models can be deployed"
    )

with col2:
    st.markdown("### Notifications")
    
    notify_new_models = st.checkbox(
        "Notify team of new models",
        value=True,
        help="Send notifications when new models are trained"
    )
    
    notify_deployments = st.checkbox(
        "Notify team of deployments",
        value=True,
        help="Send notifications when models are deployed"
    )
    
    notify_issues = st.checkbox(
        "Notify of performance issues",
        value=True,
        help="Send alerts when models underperform"
    )

if st.button("Save Settings", type="primary"):
    st.success("Collaboration settings saved!")
    # In a real system, these would be saved to the database

# Team statistics
st.markdown("---")
st.markdown("## 📈 Team Statistics")

# Calculate team statistics
if users:
    col1, col2, col3 = st.columns(3)
    
    with col1:
        # Most active user
        if recent_activity:
            most_active = max(set([a[0] for a in recent_activity]), key=[a[0] for a in recent_activity].count)
            st.metric("Most Active User", most_active)
        else:
            st.metric("Most Active User", "N/A")
    
    with col2:
        # Total team models
        conn = sqlite3.connect('mlops_platform.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM models")
        total_team_models = cursor.fetchone()[0]
        conn.close()
        st.metric("Total Team Models", total_team_models)
    
    with col3:
        # Team growth (new users in last 30 days)
        recent_users = len([u for u in users if u[2] and (datetime.now() - datetime.fromisoformat(u[2].replace('Z', '+00:00'))).days <= 30])
        st.metric("New Users (30d)", recent_users)

# Help section
with st.expander("📚 Team Management Help"):
    st.markdown("""
    ### Role Descriptions
    
    **Admin:**
    - Full system access
    - Can manage all users and settings
    - Can view and manage all models and deployments
    - Can delete any data
    
    **Data Scientist:**
    - Can upload data and train models
    - Can deploy their own models
    - Can view team activity
    - Cannot manage users or system settings
    
    **Viewer:**
    - Read-only access to dashboard
    - Can view public models and deployments
    - Cannot create or modify anything
    
    ### Best Practices
    
    1. **Principle of Least Privilege**: Give users only the permissions they need
    2. **Regular Reviews**: Periodically review user roles and access
    3. **Activity Monitoring**: Keep track of team activity for security
    4. **Clear Guidelines**: Establish clear policies for model sharing and collaboration
    5. **Training**: Ensure team members understand their roles and responsibilities
    
    ### Security Guidelines
    
    - Use strong passwords and encourage password changes
    - Monitor for unusual activity patterns
    - Regularly audit user permissions
    - Set up automated alerts for sensitive actions
    - Keep audit logs for compliance
    """)
