import sqlite3
import os
from datetime import datetime

def init_database():
    """Initialize the SQLite database with all required tables."""
    conn = sqlite3.connect('mlops_platform.db')
    cursor = conn.cursor()
    
    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'Viewer',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP
        )
    ''')
    
    # Datasets table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS datasets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            filename TEXT NOT NULL,
            file_path TEXT NOT NULL,
            file_size INTEGER,
            uploaded_by TEXT NOT NULL,
            uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            description TEXT,
            columns_info TEXT,
            row_count INTEGER
        )
    ''')
    
    # Models table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS models (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            algorithm TEXT NOT NULL,
            dataset_id INTEGER,
            target_column TEXT,
            feature_columns TEXT,
            hyperparameters TEXT,
            accuracy REAL,
            precision_score REAL,
            recall_score REAL,
            f1_score REAL,
            model_path TEXT,
            status TEXT DEFAULT 'training',
            created_by TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            version INTEGER DEFAULT 1,
            tags TEXT,
            description TEXT,
            FOREIGN KEY (dataset_id) REFERENCES datasets (id)
        )
    ''')
    
    # Deployments table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS deployments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            model_id INTEGER,
            endpoint_name TEXT UNIQUE NOT NULL,
            status TEXT DEFAULT 'inactive',
            deployed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            deployed_by TEXT NOT NULL,
            api_endpoint TEXT,
            prediction_count INTEGER DEFAULT 0,
            last_prediction TIMESTAMP,
            FOREIGN KEY (model_id) REFERENCES models (id)
        )
    ''')
    
    # Model predictions table (for monitoring)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            model_id INTEGER,
            input_data TEXT,
            prediction REAL,
            confidence REAL,
            predicted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            actual_value REAL,
            FOREIGN KEY (model_id) REFERENCES models (id)
        )
    ''')
    
    # Audit logs table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            action TEXT NOT NULL,
            resource_type TEXT,
            resource_id INTEGER,
            details TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create default admin user if not exists
    cursor.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
    if cursor.fetchone()[0] == 0:
        import hashlib
        admin_password = hashlib.sha256("admin123".encode()).hexdigest()
        cursor.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
            ("admin", admin_password, "Admin")
        )
    
    conn.commit()
    conn.close()
    
    # Create directories if they don't exist
    os.makedirs('models/trained_models', exist_ok=True)
    os.makedirs('data/uploads', exist_ok=True)

def log_action(user_id, action, resource_type=None, resource_id=None, details=None):
    """Log user actions for audit trail."""
    conn = sqlite3.connect('mlops_platform.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO audit_logs (user_id, action, resource_type, resource_id, details)
        VALUES (?, ?, ?, ?, ?)
    ''', (user_id, action, resource_type, resource_id, details))
    
    conn.commit()
    conn.close()

def get_user_models(username):
    """Get all models for a specific user."""
    conn = sqlite3.connect('mlops_platform.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, name, algorithm, accuracy, status, created_at, version, tags
        FROM models 
        WHERE created_by = ?
        ORDER BY created_at DESC
    ''', (username,))
    
    models = cursor.fetchall()
    conn.close()
    return models

def get_user_datasets(username):
    """Get all datasets for a specific user."""
    conn = sqlite3.connect('mlops_platform.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, name, filename, file_size, uploaded_at, row_count
        FROM datasets 
        WHERE uploaded_by = ?
        ORDER BY uploaded_at DESC
    ''', (username,))
    
    datasets = cursor.fetchall()
    conn.close()
    return datasets
