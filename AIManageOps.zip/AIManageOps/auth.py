import streamlit as st
import sqlite3
import hashlib

def hash_password(password):
    """Hash password using SHA-256."""
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password, hashed_password):
    """Verify password against hash."""
    return hash_password(password) == hashed_password

def authenticate_user(username, password):
    """Authenticate user credentials."""
    conn = sqlite3.connect('mlops_platform.db')
    cursor = conn.cursor()
    
    cursor.execute("SELECT password_hash, role FROM users WHERE username = ?", (username,))
    result = cursor.fetchone()
    
    if result and verify_password(password, result[0]):
        # Update last login
        cursor.execute("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE username = ?", (username,))
        conn.commit()
        conn.close()
        return True, result[1]  # Return success and role
    
    conn.close()
    return False, None

def register_user(username, password, role="Viewer"):
    """Register a new user."""
    conn = sqlite3.connect('mlops_platform.db')
    cursor = conn.cursor()
    
    try:
        hashed_password = hash_password(password)
        cursor.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
            (username, hashed_password, role)
        )
        conn.commit()
        conn.close()
        return True, "User registered successfully"
    except sqlite3.IntegrityError:
        conn.close()
        return False, "Username already exists"

def get_user_role(username):
    """Get user role."""
    conn = sqlite3.connect('mlops_platform.db')
    cursor = conn.cursor()
    
    cursor.execute("SELECT role FROM users WHERE username = ?", (username,))
    result = cursor.fetchone()
    conn.close()
    
    return result[0] if result else "Viewer"

def get_all_users():
    """Get all users (admin only)."""
    conn = sqlite3.connect('mlops_platform.db')
    cursor = conn.cursor()
    
    cursor.execute("SELECT username, role, created_at, last_login FROM users ORDER BY created_at DESC")
    users = cursor.fetchall()
    conn.close()
    
    return users

def update_user_role(username, new_role):
    """Update user role (admin only)."""
    conn = sqlite3.connect('mlops_platform.db')
    cursor = conn.cursor()
    
    cursor.execute("UPDATE users SET role = ? WHERE username = ?", (new_role, username))
    conn.commit()
    conn.close()

def check_authentication():
    """Check if user is authenticated and show login form if not."""
    if 'authenticated' not in st.session_state:
        st.session_state.authenticated = False
    
    if not st.session_state.authenticated:
        st.title("🔐 Login to AI Model Lifecycle Manager")
        
        tab1, tab2 = st.tabs(["Login", "Register"])
        
        with tab1:
            with st.form("login_form"):
                username = st.text_input("Username")
                password = st.text_input("Password", type="password")
                login_button = st.form_submit_button("Login")
                
                if login_button:
                    if username and password:
                        success, role = authenticate_user(username, password)
                        if success:
                            st.session_state.authenticated = True
                            st.session_state.username = username
                            st.session_state.role = role
                            st.success("Login successful!")
                            st.rerun()
                        else:
                            st.error("Invalid username or password")
                    else:
                        st.error("Please enter both username and password")
        
        with tab2:
            with st.form("register_form"):
                new_username = st.text_input("Choose Username")
                new_password = st.text_input("Choose Password", type="password")
                confirm_password = st.text_input("Confirm Password", type="password")
                register_button = st.form_submit_button("Register")
                
                if register_button:
                    if new_username and new_password and confirm_password:
                        if new_password == confirm_password:
                            if len(new_password) >= 6:
                                success, message = register_user(new_username, new_password)
                                if success:
                                    st.success(message)
                                    st.info("Please login with your new credentials")
                                else:
                                    st.error(message)
                            else:
                                st.error("Password must be at least 6 characters long")
                        else:
                            st.error("Passwords do not match")
                    else:
                        st.error("Please fill in all fields")
        
        return False
    
    return True
