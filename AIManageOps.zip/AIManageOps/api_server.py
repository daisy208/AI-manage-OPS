from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ValidationError
from typing import Dict, Any, Optional
import sqlite3
import json
import os
import logging
from datetime import datetime
import uvicorn
from utils.model_utils import load_model_package, make_prediction, validate_model_health

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="ML Model API Server",
    description="REST API for serving deployed machine learning models",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer(auto_error=False)

# Request/Response models
class PredictionRequest(BaseModel):
    """Request model for predictions."""
    features: Dict[str, Any]
    include_confidence: bool = True
    log_prediction: bool = True

class PredictionResponse(BaseModel):
    """Response model for predictions."""
    prediction: Any
    confidence: float
    model_name: str
    endpoint: str
    timestamp: str
    model_version: int
    processing_time_ms: float

class ModelHealthResponse(BaseModel):
    """Response model for model health checks."""
    endpoint: str
    status: str
    is_healthy: bool
    last_prediction: Optional[str]
    total_predictions: int
    model_info: Dict[str, Any]

class ErrorResponse(BaseModel):
    """Error response model."""
    error: str
    detail: str
    timestamp: str

# Database functions
def get_deployment_info(endpoint_name: str) -> Optional[Dict[str, Any]]:
    """Get deployment information from database."""
    try:
        conn = sqlite3.connect('mlops_platform.db')
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT d.id, d.model_id, d.endpoint_name, d.status, d.prediction_count,
                   m.name, m.model_path, m.algorithm, m.version
            FROM deployments d
            JOIN models m ON d.model_id = m.id
            WHERE d.endpoint_name = ? AND d.status = 'active'
        """, (endpoint_name,))
        
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return {
                'deployment_id': result[0],
                'model_id': result[1],
                'endpoint_name': result[2],
                'status': result[3],
                'prediction_count': result[4],
                'model_name': result[5],
                'model_path': result[6],
                'algorithm': result[7],
                'version': result[8]
            }
        
        return None
    
    except Exception as e:
        logger.error(f"Error getting deployment info: {str(e)}")
        return None

def log_prediction(deployment_id: int, model_id: int, input_data: Dict[str, Any], 
                  prediction: Any, confidence: float) -> bool:
    """Log a prediction to the database."""
    try:
        conn = sqlite3.connect('mlops_platform.db')
        cursor = conn.cursor()
        
        # Insert prediction log
        cursor.execute("""
            INSERT INTO predictions (model_id, input_data, prediction, confidence)
            VALUES (?, ?, ?, ?)
        """, (model_id, json.dumps(input_data), float(prediction) if isinstance(prediction, (int, float)) else str(prediction), confidence))
        
        # Update deployment statistics
        cursor.execute("""
            UPDATE deployments 
            SET prediction_count = prediction_count + 1, 
                last_prediction = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (deployment_id,))
        
        conn.commit()
        conn.close()
        return True
    
    except Exception as e:
        logger.error(f"Error logging prediction: {str(e)}")
        return False

def verify_api_key(credentials: HTTPAuthorizationCredentials = Depends(security)) -> Optional[str]:
    """Verify API key if authentication is required."""
    # In a production system, this would verify against stored API keys
    # For now, we'll accept any non-empty token or allow unauthenticated access
    if credentials:
        return credentials.credentials
    return "anonymous"

# API Routes
@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "message": "ML Model API Server",
        "version": "1.0.0",
        "status": "running",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/health")
async def health_check():
    """General health check endpoint."""
    try:
        # Test database connection
        conn = sqlite3.connect('mlops_platform.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM deployments WHERE status = 'active'")
        active_deployments = cursor.fetchone()[0]
        conn.close()
        
        return {
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "active_deployments": active_deployments,
            "database": "connected"
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Service unhealthy: {str(e)}"
        )

@app.get("/deployments")
async def list_deployments(api_key: str = Depends(verify_api_key)):
    """List all active deployments."""
    try:
        conn = sqlite3.connect('mlops_platform.db')
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT d.endpoint_name, d.prediction_count, d.last_prediction,
                   m.name, m.algorithm, m.version
            FROM deployments d
            JOIN models m ON d.model_id = m.id
            WHERE d.status = 'active'
            ORDER BY d.deployed_at DESC
        """)
        
        deployments = cursor.fetchall()
        conn.close()
        
        deployment_list = []
        for deployment in deployments:
            deployment_list.append({
                'endpoint': deployment[0],
                'prediction_count': deployment[1],
                'last_prediction': deployment[2],
                'model_name': deployment[3],
                'algorithm': deployment[4],
                'version': deployment[5],
                'url': f"/predict/{deployment[0]}"
            })
        
        return {
            "deployments": deployment_list,
            "total": len(deployment_list)
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error listing deployments: {str(e)}"
        )

@app.get("/predict/{endpoint_name}/health", response_model=ModelHealthResponse)
async def model_health(endpoint_name: str, api_key: str = Depends(verify_api_key)):
    """Check health of a specific model endpoint."""
    # Get deployment info
    deployment_info = get_deployment_info(endpoint_name)
    if not deployment_info:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Deployment '{endpoint_name}' not found or inactive"
        )
    
    try:
        # Load and validate model
        model_package = load_model_package(deployment_info['model_path'])
        health_status = validate_model_health(model_package)
        
        return ModelHealthResponse(
            endpoint=endpoint_name,
            status="healthy" if health_status['is_healthy'] else "unhealthy",
            is_healthy=health_status['is_healthy'],
            last_prediction=None,  # Would be retrieved from database
            total_predictions=deployment_info['prediction_count'],
            model_info={
                'name': deployment_info['model_name'],
                'algorithm': deployment_info['algorithm'],
                'version': deployment_info['version'],
                'health_details': health_status
            }
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error checking model health: {str(e)}"
        )

@app.post("/predict/{endpoint_name}", response_model=PredictionResponse)
async def predict(
    endpoint_name: str, 
    request: PredictionRequest,
    api_key: str = Depends(verify_api_key)
):
    """Make a prediction using the specified model endpoint."""
    start_time = datetime.now()
    
    # Get deployment info
    deployment_info = get_deployment_info(endpoint_name)
    if not deployment_info:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Deployment '{endpoint_name}' not found or inactive"
        )
    
    try:
        # Load model
        model_package = load_model_package(deployment_info['model_path'])
        
        # Validate model health
        health_status = validate_model_health(model_package)
        if not health_status['is_healthy']:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=f"Model is unhealthy: {', '.join(health_status['issues'])}"
            )
        
        # Make prediction
        prediction, confidence = make_prediction(model_package, request.features)
        
        # Calculate processing time
        processing_time = (datetime.now() - start_time).total_seconds() * 1000
        
        # Log prediction if requested
        if request.log_prediction:
            log_prediction(
                deployment_info['deployment_id'],
                deployment_info['model_id'],
                request.features,
                prediction,
                confidence
            )
        
        return PredictionResponse(
            prediction=prediction,
            confidence=confidence if request.include_confidence else 1.0,
            model_name=deployment_info['model_name'],
            endpoint=endpoint_name,
            timestamp=datetime.now().isoformat(),
            model_version=deployment_info['version'],
            processing_time_ms=round(processing_time, 2)
        )
    
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Prediction error for {endpoint_name}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal server error: {str(e)}"
        )

@app.post("/predict/{endpoint_name}/batch")
async def batch_predict(
    endpoint_name: str,
    requests: list[PredictionRequest],
    api_key: str = Depends(verify_api_key)
):
    """Make batch predictions using the specified model endpoint."""
    if len(requests) > 100:  # Limit batch size
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Batch size cannot exceed 100 predictions"
        )
    
    # Get deployment info
    deployment_info = get_deployment_info(endpoint_name)
    if not deployment_info:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Deployment '{endpoint_name}' not found or inactive"
        )
    
    try:
        # Load model once for all predictions
        model_package = load_model_package(deployment_info['model_path'])
        
        # Validate model health
        health_status = validate_model_health(model_package)
        if not health_status['is_healthy']:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=f"Model is unhealthy: {', '.join(health_status['issues'])}"
            )
        
        results = []
        start_time = datetime.now()
        
        for i, request in enumerate(requests):
            try:
                prediction, confidence = make_prediction(model_package, request.features)
                
                # Log prediction if requested
                if request.log_prediction:
                    log_prediction(
                        deployment_info['deployment_id'],
                        deployment_info['model_id'],
                        request.features,
                        prediction,
                        confidence
                    )
                
                results.append({
                    "index": i,
                    "prediction": prediction,
                    "confidence": confidence if request.include_confidence else 1.0,
                    "status": "success"
                })
            
            except Exception as e:
                results.append({
                    "index": i,
                    "error": str(e),
                    "status": "error"
                })
        
        processing_time = (datetime.now() - start_time).total_seconds() * 1000
        
        return {
            "results": results,
            "total_requests": len(requests),
            "successful_predictions": len([r for r in results if r["status"] == "success"]),
            "failed_predictions": len([r for r in results if r["status"] == "error"]),
            "model_name": deployment_info['model_name'],
            "endpoint": endpoint_name,
            "timestamp": datetime.now().isoformat(),
            "total_processing_time_ms": round(processing_time, 2)
        }
    
    except Exception as e:
        logger.error(f"Batch prediction error for {endpoint_name}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal server error: {str(e)}"
        )

@app.get("/predict/{endpoint_name}/schema")
async def get_model_schema(endpoint_name: str, api_key: str = Depends(verify_api_key)):
    """Get the input schema for a model endpoint."""
    # Get deployment info
    deployment_info = get_deployment_info(endpoint_name)
    if not deployment_info:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Deployment '{endpoint_name}' not found or inactive"
        )
    
    try:
        # Load model to get feature information
        model_package = load_model_package(deployment_info['model_path'])
        
        schema = {
            "endpoint": endpoint_name,
            "model_name": deployment_info['model_name'],
            "algorithm": deployment_info['algorithm'],
            "problem_type": model_package.get('problem_type', 'Unknown'),
            "target_column": model_package.get('target_column', 'Unknown'),
            "required_features": model_package.get('feature_columns', []),
            "feature_count": len(model_package.get('feature_columns', [])),
            "example_request": {
                "features": {feature: f"<{feature}_value>" for feature in model_package.get('feature_columns', [])},
                "include_confidence": True,
                "log_prediction": True
            },
            "example_response": {
                "prediction": "<predicted_value>",
                "confidence": "<confidence_score>",
                "model_name": deployment_info['model_name'],
                "endpoint": endpoint_name,
                "timestamp": "<iso_timestamp>",
                "model_version": deployment_info['version'],
                "processing_time_ms": "<processing_time>"
            }
        }
        
        return schema
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error getting model schema: {str(e)}"
        )

# Exception handlers
@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    return ErrorResponse(
        error=exc.detail,
        detail=f"HTTP {exc.status_code}",
        timestamp=datetime.now().isoformat()
    )

@app.exception_handler(ValidationError)
async def validation_exception_handler(request, exc):
    return ErrorResponse(
        error="Validation error",
        detail=str(exc),
        timestamp=datetime.now().isoformat()
    )

# Startup event
@app.on_event("startup")
async def startup_event():
    """Initialize the API server."""
    logger.info("Starting ML Model API Server...")
    
    # Check if database exists
    if not os.path.exists('mlops_platform.db'):
        logger.warning("Database not found. Make sure to run the Streamlit app first to initialize the database.")
    
    # Check if models directory exists
    if not os.path.exists('models/trained_models'):
        logger.warning("Models directory not found. No models will be available for serving.")
    
    logger.info("ML Model API Server started successfully!")

if __name__ == "__main__":
    uvicorn.run(
        "api_server:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
