import streamlit as st
import sqlite3
from auth import check_authentication, get_user_role
from database import init_database

# Page configuration
st.set_page_config(
    page_title="AI Model Lifecycle Manager",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize database
init_database()

# Authentication check
if not check_authentication():
    st.stop()

# Get current user info
user_role = get_user_role(st.session_state.username)

# Main page content
st.title("🤖 AI Model Lifecycle Manager")
st.markdown("### Streamline your machine learning workflows—without writing a single line of code.")

# Display user info and role
col1, col2, col3 = st.columns([2, 1, 1])
with col1:
    st.write(f"Welcome, **{st.session_state.username}**")
with col2:
    st.write(f"Role: **{user_role}**")
with col3:
    if st.button("Logout"):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.rerun()

st.markdown("---")

# Dashboard overview
st.markdown("## 📊 Dashboard Overview")

# Create metrics row
col1, col2, col3, col4 = st.columns(4)

# Get metrics from database
conn = sqlite3.connect('mlops_platform.db')
cursor = conn.cursor()

# Total models
cursor.execute("SELECT COUNT(*) FROM models WHERE created_by = ?", (st.session_state.username,))
total_models = cursor.fetchone()[0]

# Active deployments
cursor.execute("SELECT COUNT(*) FROM deployments WHERE status = 'active' AND model_id IN (SELECT id FROM models WHERE created_by = ?)", (st.session_state.username,))
active_deployments = cursor.fetchone()[0]

# Recent uploads
cursor.execute("SELECT COUNT(*) FROM datasets WHERE uploaded_by = ? AND uploaded_at > datetime('now', '-7 days')", (st.session_state.username,))
recent_uploads = cursor.fetchone()[0]

# Models in training
cursor.execute("SELECT COUNT(*) FROM models WHERE status = 'training' AND created_by = ?", (st.session_state.username,))
training_models = cursor.fetchone()[0]

conn.close()

with col1:
    st.metric("Total Models", total_models)
with col2:
    st.metric("Active Deployments", active_deployments)
with col3:
    st.metric("Recent Uploads", recent_uploads)
with col4:
    st.metric("Training Models", training_models)

# Recent activity
st.markdown("## 📈 Recent Activity")

conn = sqlite3.connect('mlops_platform.db')
cursor = conn.cursor()

# Get recent models
cursor.execute("""
    SELECT name, algorithm, accuracy, status, created_at 
    FROM models 
    WHERE created_by = ? 
    ORDER BY created_at DESC 
    LIMIT 5
""", (st.session_state.username,))

recent_models = cursor.fetchall()
conn.close()

if recent_models:
    import pandas as pd
    df = pd.DataFrame(recent_models, columns=['Model Name', 'Algorithm', 'Accuracy', 'Status', 'Created At'])
    st.dataframe(df, use_container_width=True)
else:
    st.info("No models found. Start by uploading data and training your first model!")

# Quick actions
st.markdown("## 🚀 Quick Actions")

col1, col2, col3 = st.columns(3)

with col1:
    if st.button("📁 Upload New Data", use_container_width=True):
        st.switch_page("pages/1_Data_Upload.py")

with col2:
    if st.button("🔬 Train Model", use_container_width=True):
        st.switch_page("pages/2_Model_Training.py")

with col3:
    if st.button("📋 View Registry", use_container_width=True):
        st.switch_page("pages/3_Model_Registry.py")

# Platform features
st.markdown("## 🛠️ Platform Features")

features = [
    "🤖 **Model Training & AutoML**: Upload data, select algorithms, and train models in minutes",
    "📚 **Model Registry**: Organize and version your models with tags and performance metrics",
    "🚀 **One-Click Deployment**: Instantly generate APIs to serve your models in production",
    "📊 **Monitoring & Drift Detection**: Track performance and detect data drift",
    "🔍 **Explainable AI**: Visualize feature importance and interpret predictions",
    "👥 **Collaboration Tools**: Invite teammates and manage roles securely"
]

for feature in features:
    st.markdown(feature)

# Sidebar navigation help
with st.sidebar:
    st.markdown("## 🧭 Navigation")
    st.markdown("""
    Use the pages in the sidebar to:
    - **Data Upload**: Import and preview your datasets
    - **Model Training**: Train ML models with different algorithms
    - **Model Registry**: View and manage your trained models
    - **Model Deployment**: Deploy models as API endpoints
    - **Monitoring**: Track model performance over time
    - **Team Management**: Manage users and permissions
    """)
    
    if user_role in ['Admin', 'Data Scientist']:
        st.markdown("### 🔧 Admin Tools")
        st.markdown("You have elevated permissions to manage models and deployments.")
