import pandas as pd
import numpy as np
import json
from typing import Dict, List, Any, Tuple, Optional
import os
from datetime import datetime

def load_dataset(file_path: str) -> pd.DataFrame:
    """
    Load a dataset from a file path.
    
    Args:
        file_path: Path to the dataset file
        
    Returns:
        Loaded pandas DataFrame
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Dataset file not found: {file_path}")
    
    try:
        if file_path.endswith('.csv'):
            df = pd.read_csv(file_path)
        elif file_path.endswith('.json'):
            df = pd.read_json(file_path)
        else:
            raise ValueError(f"Unsupported file format: {file_path}")
        
        return df
    except Exception as e:
        raise ValueError(f"Error loading dataset: {str(e)}")

def analyze_dataset(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Perform comprehensive analysis of a dataset.
    
    Args:
        df: pandas DataFrame to analyze
        
    Returns:
        Dictionary containing analysis results
    """
    analysis = {
        'basic_info': {
            'shape': df.shape,
            'columns': df.columns.tolist(),
            'dtypes': df.dtypes.to_dict(),
            'memory_usage': df.memory_usage(deep=True).sum()
        },
        'missing_data': {
            'total_missing': df.isnull().sum().sum(),
            'missing_by_column': df.isnull().sum().to_dict(),
            'missing_percentage': (df.isnull().sum() / len(df) * 100).to_dict()
        },
        'data_types': {
            'numeric_columns': df.select_dtypes(include=[np.number]).columns.tolist(),
            'categorical_columns': df.select_dtypes(include=['object']).columns.tolist(),
            'datetime_columns': df.select_dtypes(include=['datetime64']).columns.tolist()
        },
        'statistics': {},
        'data_quality': {}
    }
    
    # Numeric statistics
    numeric_cols = analysis['data_types']['numeric_columns']
    if numeric_cols:
        analysis['statistics']['numeric'] = df[numeric_cols].describe().to_dict()
    
    # Categorical statistics
    categorical_cols = analysis['data_types']['categorical_columns']
    if categorical_cols:
        cat_stats = {}
        for col in categorical_cols:
            cat_stats[col] = {
                'unique_count': df[col].nunique(),
                'most_frequent': df[col].mode().iloc[0] if len(df[col].mode()) > 0 else None,
                'value_counts': df[col].value_counts().head(10).to_dict()
            }
        analysis['statistics']['categorical'] = cat_stats
    
    # Data quality assessment
    analysis['data_quality'] = assess_data_quality(df)
    
    return analysis

def assess_data_quality(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Assess the quality of data in a DataFrame.
    
    Args:
        df: pandas DataFrame to assess
        
    Returns:
        Dictionary with data quality metrics and issues
    """
    quality_report = {
        'overall_score': 0.0,
        'issues': [],
        'warnings': [],
        'recommendations': []
    }
    
    score = 100.0  # Start with perfect score
    
    # Check for missing data
    missing_percentage = (df.isnull().sum().sum() / (len(df) * len(df.columns))) * 100
    if missing_percentage > 20:
        quality_report['issues'].append(f"High missing data rate: {missing_percentage:.1f}%")
        score -= 20
    elif missing_percentage > 5:
        quality_report['warnings'].append(f"Moderate missing data rate: {missing_percentage:.1f}%")
        score -= 10
    
    # Check for duplicate rows
    duplicate_count = df.duplicated().sum()
    if duplicate_count > 0:
        duplicate_percentage = (duplicate_count / len(df)) * 100
        if duplicate_percentage > 10:
            quality_report['issues'].append(f"High duplicate rate: {duplicate_percentage:.1f}%")
            score -= 15
        else:
            quality_report['warnings'].append(f"Some duplicate rows found: {duplicate_count}")
            score -= 5
    
    # Check for constant columns
    constant_cols = [col for col in df.columns if df[col].nunique() <= 1]
    if constant_cols:
        quality_report['warnings'].append(f"Constant columns found: {constant_cols}")
        quality_report['recommendations'].append("Consider removing constant columns")
        score -= 5
    
    # Check for high cardinality categorical columns
    for col in df.select_dtypes(include=['object']).columns:
        unique_ratio = df[col].nunique() / len(df)
        if unique_ratio > 0.5:
            quality_report['warnings'].append(f"High cardinality categorical column: {col}")
            quality_report['recommendations'].append(f"Consider encoding or grouping values in {col}")
    
    # Check for outliers in numeric columns
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    outlier_cols = []
    for col in numeric_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        outliers = ((df[col] < lower_bound) | (df[col] > upper_bound)).sum()
        outlier_percentage = (outliers / len(df)) * 100
        if outlier_percentage > 5:
            outlier_cols.append(col)
    
    if outlier_cols:
        quality_report['warnings'].append(f"Columns with potential outliers: {outlier_cols}")
        quality_report['recommendations'].append("Review and handle outliers before training")
    
    # Check data distribution
    for col in numeric_cols:
        skewness = df[col].skew()
        if abs(skewness) > 2:
            quality_report['warnings'].append(f"Highly skewed column: {col} (skewness: {skewness:.2f})")
            quality_report['recommendations'].append(f"Consider transforming {col} to reduce skewness")
    
    quality_report['overall_score'] = max(0.0, score)
    
    return quality_report

def prepare_data_for_training(df: pd.DataFrame, target_column: str, test_size: float = 0.2) -> Dict[str, Any]:
    """
    Prepare data for machine learning training.
    
    Args:
        df: Input DataFrame
        target_column: Name of the target column
        test_size: Proportion of data to use for testing
        
    Returns:
        Dictionary with prepared data and metadata
    """
    if target_column not in df.columns:
        raise ValueError(f"Target column '{target_column}' not found in dataset")
    
    # Separate features and target
    feature_columns = [col for col in df.columns if col != target_column]
    X = df[feature_columns].copy()
    y = df[target_column].copy()
    
    # Analyze target variable
    target_analysis = analyze_target_variable(y)
    
    # Handle missing values
    missing_strategy = determine_missing_strategy(X)
    X_clean = handle_missing_values(X, missing_strategy)
    y_clean = y.dropna()
    
    # Align X and y after cleaning
    common_index = X_clean.index.intersection(y_clean.index)
    X_clean = X_clean.loc[common_index]
    y_clean = y_clean.loc[common_index]
    
    # Detect categorical columns
    categorical_columns = X_clean.select_dtypes(include=['object']).columns.tolist()
    numeric_columns = X_clean.select_dtypes(include=[np.number]).columns.tolist()
    
    preparation_info = {
        'original_shape': df.shape,
        'cleaned_shape': (len(X_clean), len(X_clean.columns)),
        'feature_columns': feature_columns,
        'categorical_columns': categorical_columns,
        'numeric_columns': numeric_columns,
        'target_analysis': target_analysis,
        'missing_strategy': missing_strategy,
        'data_ready': True
    }
    
    return {
        'X': X_clean,
        'y': y_clean,
        'info': preparation_info
    }

def analyze_target_variable(y: pd.Series) -> Dict[str, Any]:
    """
    Analyze the target variable to determine problem type and characteristics.
    
    Args:
        y: Target variable series
        
    Returns:
        Dictionary with target variable analysis
    """
    analysis = {
        'name': y.name,
        'dtype': str(y.dtype),
        'shape': y.shape,
        'missing_count': y.isnull().sum(),
        'unique_count': y.nunique()
    }
    
    # Determine problem type
    if y.dtype in ['int64', 'float64'] and y.nunique() > 20:
        analysis['problem_type'] = 'Regression'
        analysis['statistics'] = {
            'mean': y.mean(),
            'std': y.std(),
            'min': y.min(),
            'max': y.max(),
            'median': y.median()
        }
    else:
        analysis['problem_type'] = 'Classification'
        analysis['class_distribution'] = y.value_counts().to_dict()
        analysis['class_balance'] = y.value_counts(normalize=True).to_dict()
        
        # Check for class imbalance
        min_class_ratio = min(analysis['class_balance'].values())
        if min_class_ratio < 0.1:
            analysis['imbalance_warning'] = True
            analysis['recommendations'] = ['Consider using class balancing techniques']
        else:
            analysis['imbalance_warning'] = False
    
    return analysis

def determine_missing_strategy(df: pd.DataFrame) -> Dict[str, str]:
    """
    Determine the best strategy for handling missing values in each column.
    
    Args:
        df: DataFrame to analyze
        
    Returns:
        Dictionary mapping column names to missing value strategies
    """
    strategies = {}
    
    for col in df.columns:
        missing_percentage = (df[col].isnull().sum() / len(df)) * 100
        
        if missing_percentage == 0:
            strategies[col] = 'none'
        elif missing_percentage > 50:
            strategies[col] = 'drop_column'
        elif df[col].dtype in ['int64', 'float64']:
            # Numeric columns
            if missing_percentage < 5:
                strategies[col] = 'mean'
            else:
                strategies[col] = 'median'
        else:
            # Categorical columns
            strategies[col] = 'mode'
    
    return strategies

def handle_missing_values(df: pd.DataFrame, strategies: Dict[str, str]) -> pd.DataFrame:
    """
    Handle missing values according to the specified strategies.
    
    Args:
        df: DataFrame with missing values
        strategies: Dictionary mapping columns to strategies
        
    Returns:
        DataFrame with missing values handled
    """
    df_clean = df.copy()
    
    for col, strategy in strategies.items():
        if col not in df_clean.columns:
            continue
            
        if strategy == 'drop_column':
            df_clean = df_clean.drop(columns=[col])
        elif strategy == 'mean':
            df_clean[col] = df_clean[col].fillna(df_clean[col].mean())
        elif strategy == 'median':
            df_clean[col] = df_clean[col].fillna(df_clean[col].median())
        elif strategy == 'mode':
            mode_value = df_clean[col].mode()
            if len(mode_value) > 0:
                df_clean[col] = df_clean[col].fillna(mode_value.iloc[0])
            else:
                df_clean[col] = df_clean[col].fillna('Unknown')
    
    return df_clean

def generate_column_info(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """
    Generate detailed information about each column in the DataFrame.
    
    Args:
        df: DataFrame to analyze
        
    Returns:
        List of dictionaries with column information
    """
    column_info = []
    
    for col in df.columns:
        info = {
            'name': col,
            'dtype': str(df[col].dtype),
            'null_count': int(df[col].isnull().sum()),
            'null_percentage': float((df[col].isnull().sum() / len(df)) * 100),
            'unique_count': int(df[col].nunique()),
            'memory_usage': int(df[col].memory_usage(deep=True))
        }
        
        # Add type-specific information
        if df[col].dtype in ['int64', 'float64']:
            info.update({
                'data_type': 'numeric',
                'min_value': float(df[col].min()) if not df[col].isnull().all() else None,
                'max_value': float(df[col].max()) if not df[col].isnull().all() else None,
                'mean_value': float(df[col].mean()) if not df[col].isnull().all() else None,
                'std_value': float(df[col].std()) if not df[col].isnull().all() else None
            })
        else:
            info.update({
                'data_type': 'categorical',
                'most_frequent': str(df[col].mode().iloc[0]) if len(df[col].mode()) > 0 else None,
                'sample_values': df[col].dropna().unique()[:5].tolist()
            })
        
        column_info.append(info)
    
    return column_info

def validate_dataset_for_ml(df: pd.DataFrame, target_column: str) -> Dict[str, Any]:
    """
    Validate if a dataset is suitable for machine learning.
    
    Args:
        df: DataFrame to validate
        target_column: Name of the target column
        
    Returns:
        Dictionary with validation results
    """
    validation = {
        'is_valid': True,
        'errors': [],
        'warnings': [],
        'recommendations': []
    }
    
    # Check basic requirements
    if len(df) < 10:
        validation['errors'].append("Dataset too small (less than 10 rows)")
        validation['is_valid'] = False
    
    if len(df.columns) < 2:
        validation['errors'].append("Dataset must have at least 2 columns (features + target)")
        validation['is_valid'] = False
    
    if target_column not in df.columns:
        validation['errors'].append(f"Target column '{target_column}' not found")
        validation['is_valid'] = False
        return validation
    
    # Check target variable
    target_missing = df[target_column].isnull().sum()
    if target_missing > len(df) * 0.5:
        validation['errors'].append(f"Target column has too many missing values ({target_missing})")
        validation['is_valid'] = False
    elif target_missing > 0:
        validation['warnings'].append(f"Target column has {target_missing} missing values")
    
    # Check feature columns
    feature_columns = [col for col in df.columns if col != target_column]
    if len(feature_columns) == 0:
        validation['errors'].append("No feature columns available")
        validation['is_valid'] = False
    
    # Check for all missing feature columns
    all_missing_features = []
    for col in feature_columns:
        if df[col].isnull().all():
            all_missing_features.append(col)
    
    if all_missing_features:
        validation['warnings'].append(f"Columns with all missing values: {all_missing_features}")
        validation['recommendations'].append("Remove columns with all missing values")
    
    # Check data diversity
    constant_features = []
    for col in feature_columns:
        if df[col].nunique() <= 1:
            constant_features.append(col)
    
    if constant_features:
        validation['warnings'].append(f"Constant feature columns: {constant_features}")
        validation['recommendations'].append("Remove constant feature columns")
    
    # Check sample size recommendations
    feature_count = len([col for col in feature_columns if col not in all_missing_features and col not in constant_features])
    recommended_samples = feature_count * 10
    
    if len(df) < recommended_samples:
        validation['warnings'].append(f"Small dataset for {feature_count} features. Recommended: {recommended_samples}+ samples")
        validation['recommendations'].append("Consider collecting more data for better model performance")
    
    return validation
