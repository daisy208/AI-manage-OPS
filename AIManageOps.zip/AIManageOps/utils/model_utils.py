import joblib
import numpy as np
import pandas as pd
import json
from sklearn.preprocessing import StandardScaler, LabelEncoder
from typing import Dict, Any, Tuple, List
import os
from lime.lime_tabular import LimeTabularExplainer
from lime.explanation import Explanation

def load_model_package(model_path: str) -> Dict[str, Any]:
    """
    Load a complete model package including model, preprocessors, and metadata.
    
    Args:
        model_path: Path to the saved model file
        
    Returns:
        Dictionary containing model and associated components
    """
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model file not found: {model_path}")
    
    try:
        model_package = joblib.load(model_path)
        return model_package
    except Exception as e:
        raise ValueError(f"Error loading model package: {str(e)}")

def preprocess_input_data(input_data: Dict[str, Any], model_package: Dict[str, Any]) -> np.ndarray:
    """
    Preprocess input data using the saved preprocessors from model training.
    
    Args:
        input_data: Dictionary of feature values
        model_package: Loaded model package with preprocessors
        
    Returns:
        Preprocessed numpy array ready for prediction
    """
    try:
        # Get expected features
        feature_columns = model_package['feature_columns']
        
        # Check if all required features are present
        missing_features = [col for col in feature_columns if col not in input_data]
        if missing_features:
            raise ValueError(f"Missing required features: {missing_features}")
        
        # Create DataFrame with features in correct order
        df = pd.DataFrame([input_data])[feature_columns]
        
        # Apply label encoders for categorical features
        if 'label_encoders' in model_package and model_package['label_encoders']:
            for col, encoder in model_package['label_encoders'].items():
                if col in df.columns:
                    try:
                        df[col] = encoder.transform(df[col].astype(str))
                    except ValueError:
                        # Handle unseen categories by using the most frequent class
                        df[col] = encoder.transform([encoder.classes_[0]])[0]
        
        # Apply scaler if present
        if 'scaler' in model_package and model_package['scaler'] is not None:
            df_scaled = model_package['scaler'].transform(df)
            return df_scaled
        
        return df.values
        
    except Exception as e:
        raise ValueError(f"Error preprocessing input data: {str(e)}")

def make_prediction(model_package: Dict[str, Any], input_data: Dict[str, Any]) -> Tuple[Any, float]:
    """
    Make a prediction using the loaded model and input data.
    
    Args:
        model_package: Loaded model package
        input_data: Dictionary of feature values
        
    Returns:
        Tuple of (prediction, confidence_score)
    """
    try:
        # Preprocess input data
        X = preprocess_input_data(input_data, model_package)
        
        # Get model and make prediction
        model = model_package['model']
        prediction = model.predict(X)[0]
        
        # Calculate confidence score
        confidence = calculate_confidence(model, X, model_package['problem_type'])
        
        # Apply target encoder if present (for classification)
        if 'target_encoder' in model_package and model_package['target_encoder'] is not None:
            try:
                prediction = model_package['target_encoder'].inverse_transform([int(prediction)])[0]
            except:
                pass  # Keep original prediction if transformation fails
        
        return prediction, confidence
        
    except Exception as e:
        raise ValueError(f"Error making prediction: {str(e)}")

def calculate_confidence(model: Any, X: np.ndarray, problem_type: str) -> float:
    """
    Calculate confidence score for a prediction.
    
    Args:
        model: Trained model
        X: Preprocessed input features
        problem_type: 'Classification' or 'Regression'
        
    Returns:
        Confidence score between 0 and 1
    """
    try:
        if problem_type == 'Classification':
            # Use prediction probability for confidence
            if hasattr(model, 'predict_proba'):
                probabilities = model.predict_proba(X)[0]
                confidence = np.max(probabilities)
            elif hasattr(model, 'decision_function'):
                # For models with decision function (like SVM)
                decision_scores = model.decision_function(X)[0]
                if isinstance(decision_scores, np.ndarray):
                    confidence = np.max(np.abs(decision_scores)) / 10.0  # Normalize roughly
                else:
                    confidence = min(abs(decision_scores) / 10.0, 1.0)
            else:
                # Default confidence for classification
                confidence = 0.8
        else:
            # For regression, use a heuristic based on model type
            if hasattr(model, 'score'):
                # Use model's R² score as a proxy for confidence
                confidence = 0.85  # Default for regression
            else:
                confidence = 0.8
        
        # Ensure confidence is between 0 and 1
        return max(0.0, min(1.0, confidence))
        
    except Exception:
        # Return default confidence if calculation fails
        return 0.75

def validate_model_health(model_package: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate that a model package is healthy and ready for predictions.
    
    Args:
        model_package: Loaded model package
        
    Returns:
        Dictionary with health status and any issues found
    """
    health_status = {
        'is_healthy': True,
        'issues': [],
        'warnings': []
    }
    
    try:
        # Check required components
        required_components = ['model', 'feature_columns', 'target_column', 'problem_type']
        for component in required_components:
            if component not in model_package:
                health_status['issues'].append(f"Missing required component: {component}")
                health_status['is_healthy'] = False
        
        # Check model object
        if 'model' in model_package:
            model = model_package['model']
            if not hasattr(model, 'predict'):
                health_status['issues'].append("Model object does not have predict method")
                health_status['is_healthy'] = False
        
        # Check feature columns
        if 'feature_columns' in model_package:
            if not isinstance(model_package['feature_columns'], list) or len(model_package['feature_columns']) == 0:
                health_status['issues'].append("Feature columns must be a non-empty list")
                health_status['is_healthy'] = False
        
        # Check problem type
        if 'problem_type' in model_package:
            if model_package['problem_type'] not in ['Classification', 'Regression']:
                health_status['issues'].append("Problem type must be 'Classification' or 'Regression'")
                health_status['is_healthy'] = False
        
        # Warnings for optional components
        if 'scaler' not in model_package:
            health_status['warnings'].append("No scaler found - features will not be scaled")
        
        if 'label_encoders' not in model_package:
            health_status['warnings'].append("No label encoders found - categorical features may not be handled properly")
        
    except Exception as e:
        health_status['issues'].append(f"Error validating model: {str(e)}")
        health_status['is_healthy'] = False
    
    return health_status

def get_feature_importance(model_package: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract feature importance from a model if available.
    
    Args:
        model_package: Loaded model package
        
    Returns:
        List of dictionaries with feature names and importance scores
    """
    try:
        model = model_package['model']
        feature_columns = model_package['feature_columns']
        
        importance_list = []
        
        if hasattr(model, 'feature_importances_'):
            # Tree-based models (Random Forest, XGBoost)
            importances = model.feature_importances_
            for feature, importance in zip(feature_columns, importances):
                importance_list.append({
                    'feature': feature,
                    'importance': float(importance),
                    'type': 'feature_importance'
                })
        
        elif hasattr(model, 'coef_'):
            # Linear models
            coefficients = model.coef_
            if len(coefficients.shape) > 1:
                # Multi-class classification
                coefficients = np.mean(np.abs(coefficients), axis=0)
            else:
                coefficients = np.abs(coefficients)
            
            # Normalize coefficients
            if np.sum(coefficients) > 0:
                coefficients = coefficients / np.sum(coefficients)
            
            for feature, coef in zip(feature_columns, coefficients):
                importance_list.append({
                    'feature': feature,
                    'importance': float(coef),
                    'type': 'coefficient'
                })
        
        # Sort by importance
        importance_list.sort(key=lambda x: x['importance'], reverse=True)
        
        return importance_list
        
    except Exception as e:
        return [{'error': f"Could not extract feature importance: {str(e)}"}]

def generate_model_summary(model_package: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate a comprehensive summary of a model package.
    
    Args:
        model_package: Loaded model package
        
    Returns:
        Dictionary with model summary information
    """
    try:
        summary = {
            'model_type': str(type(model_package['model']).__name__),
            'problem_type': model_package.get('problem_type', 'Unknown'),
            'target_column': model_package.get('target_column', 'Unknown'),
            'feature_count': len(model_package.get('feature_columns', [])),
            'feature_columns': model_package.get('feature_columns', []),
            'has_scaler': 'scaler' in model_package and model_package['scaler'] is not None,
            'has_label_encoders': 'label_encoders' in model_package and model_package['label_encoders'],
            'has_target_encoder': 'target_encoder' in model_package and model_package['target_encoder'] is not None
        }
        
        # Add model-specific parameters if available
        if hasattr(model_package['model'], 'get_params'):
            summary['model_parameters'] = model_package['model'].get_params()
        
        # Add feature importance if available
        summary['feature_importance'] = get_feature_importance(model_package)
        
        # Add health status
        summary['health'] = validate_model_health(model_package)
        
        return summary
        
    except Exception as e:
        return {'error': f"Error generating model summary: {str(e)}"}

def explain_prediction_lime(model_package: Dict[str, Any], input_data: Dict[str, Any], 
                           training_data: pd.DataFrame = None, num_features: int = 10) -> Dict[str, Any]:
    """
    Generate LIME explanation for a single prediction.
    
    Args:
        model_package: Loaded model package
        input_data: Dictionary of feature values to explain
        training_data: Training data for LIME (optional, will use synthetic data if not provided)
        num_features: Number of top features to include in explanation
        
    Returns:
        Dictionary containing LIME explanation data
    """
    try:
        model = model_package['model']
        feature_columns = model_package['feature_columns']
        problem_type = model_package['problem_type']
        
        # Preprocess the input data
        X_explain = preprocess_input_data(input_data, model_package)
        
        # Create or use training data for LIME
        if training_data is None:
            # Generate synthetic training data based on input features
            np.random.seed(42)
            n_samples = 1000
            
            # Create synthetic data around the input point
            synthetic_data = []
            for _ in range(n_samples):
                synthetic_sample = {}
                for feature in feature_columns:
                    if feature in input_data:
                        value = input_data[feature]
                        if isinstance(value, (int, float)):
                            # Add noise to numeric features
                            noise = np.random.normal(0, abs(value) * 0.2 + 0.1)
                            synthetic_sample[feature] = value + noise
                        else:
                            # Keep categorical features as is
                            synthetic_sample[feature] = value
                    else:
                        synthetic_sample[feature] = 0  # Default value
                synthetic_data.append(synthetic_sample)
            
            training_data = pd.DataFrame(synthetic_data)
        
        # Prepare training data for LIME
        X_train_lime = []
        for _, row in training_data.iterrows():
            try:
                X_processed = preprocess_input_data(row.to_dict(), model_package)
                X_train_lime.append(X_processed.flatten())
            except:
                continue
        
        if not X_train_lime:
            return {'error': 'Could not prepare training data for LIME'}
            
        X_train_lime = np.array(X_train_lime)
        
        # Create LIME explainer
        if problem_type == 'Classification':
            explainer = LimeTabularExplainer(
                X_train_lime,
                feature_names=feature_columns,
                class_names=['Class 0', 'Class 1'] if hasattr(model, 'classes_') and len(model.classes_) == 2 else None,
                mode='classification',
                discretize_continuous=True
            )
            
            # Create prediction function for LIME
            def predict_fn(X):
                try:
                    if hasattr(model, 'predict_proba'):
                        return model.predict_proba(X)
                    else:
                        predictions = model.predict(X)
                        # Convert to probability-like format
                        prob_array = np.zeros((len(predictions), 2))
                        for i, pred in enumerate(predictions):
                            prob_array[i, int(pred)] = 1.0
                        return prob_array
                except:
                    return np.array([[0.5, 0.5]] * len(X))
        else:
            explainer = LimeTabularExplainer(
                X_train_lime,
                feature_names=feature_columns,
                mode='regression',
                discretize_continuous=True
            )
            
            # Create prediction function for LIME
            def predict_fn(X):
                try:
                    return model.predict(X)
                except:
                    return np.zeros(len(X))
        
        # Generate explanation
        explanation = explainer.explain_instance(
            X_explain.flatten(),
            predict_fn,
            num_features=min(num_features, len(feature_columns))
        )
        
        # Extract explanation data
        explanation_data = {
            'feature_explanations': [],
            'prediction_score': explanation.local_pred[0] if hasattr(explanation, 'local_pred') else None,
            'intercept': explanation.intercept[0] if hasattr(explanation, 'intercept') else None,
            'explanation_type': 'LIME',
            'num_features_used': len(explanation.as_list())
        }
        
        # Process feature explanations
        for feature, weight in explanation.as_list():
            explanation_data['feature_explanations'].append({
                'feature': feature,
                'weight': float(weight),
                'contribution': 'positive' if weight > 0 else 'negative',
                'abs_weight': abs(float(weight))
            })
        
        # Sort by absolute weight
        explanation_data['feature_explanations'].sort(key=lambda x: x['abs_weight'], reverse=True)
        
        return explanation_data
        
    except Exception as e:
        return {'error': f"Error generating LIME explanation: {str(e)}"}

def get_prediction_explanation(model_package: Dict[str, Any], input_data: Dict[str, Any],
                             explanation_type: str = 'lime', **kwargs) -> Dict[str, Any]:
    """
    Get comprehensive prediction explanation using multiple techniques.
    
    Args:
        model_package: Loaded model package
        input_data: Dictionary of feature values to explain
        explanation_type: Type of explanation ('lime', 'feature_importance', 'both')
        **kwargs: Additional arguments for specific explanation methods
        
    Returns:
        Dictionary containing explanation data
    """
    try:
        explanations = {
            'prediction_result': None,
            'explanations': {},
            'input_data': input_data,
            'timestamp': pd.Timestamp.now().isoformat()
        }
        
        # Get the actual prediction first
        prediction, confidence = make_prediction(model_package, input_data)
        explanations['prediction_result'] = {
            'prediction': prediction,
            'confidence': confidence
        }
        
        # Feature importance explanation (always included)
        feature_importance = get_feature_importance(model_package)
        explanations['explanations']['feature_importance'] = feature_importance
        
        # LIME explanation
        if explanation_type in ['lime', 'both']:
            lime_explanation = explain_prediction_lime(
                model_package, 
                input_data, 
                num_features=kwargs.get('num_features', 10)
            )
            explanations['explanations']['lime'] = lime_explanation
        
        # Add input feature values with their contributions
        explanations['input_analysis'] = []
        for feature in model_package['feature_columns']:
            if feature in input_data:
                feature_info = {
                    'feature': feature,
                    'value': input_data[feature],
                    'importance_rank': None,
                    'lime_weight': None
                }
                
                # Find feature importance rank
                for i, fi in enumerate(feature_importance):
                    if fi.get('feature') == feature:
                        feature_info['importance_rank'] = i + 1
                        feature_info['global_importance'] = fi.get('importance', 0)
                        break
                
                # Find LIME weight if available
                if 'lime' in explanations['explanations'] and 'feature_explanations' in explanations['explanations']['lime']:
                    for lime_feat in explanations['explanations']['lime']['feature_explanations']:
                        if feature in lime_feat['feature']:
                            feature_info['lime_weight'] = lime_feat['weight']
                            feature_info['lime_contribution'] = lime_feat['contribution']
                            break
                
                explanations['input_analysis'].append(feature_info)
        
        return explanations
        
    except Exception as e:
        return {'error': f"Error generating prediction explanation: {str(e)}"}
